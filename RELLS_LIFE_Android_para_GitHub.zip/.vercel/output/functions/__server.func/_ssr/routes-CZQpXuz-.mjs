import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CZQpXuz-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var audExport = /^aud-\d{6,8}-wa\d+/;
var voiceArtists = /* @__PURE__ */ new Set([
	"voice memos",
	"notas de voz",
	"sound recorder",
	"grabadora de voz",
	"voice recorder",
	"grabadora"
]);
var voiceFolders = [
	"voice notes",
	"voicenotes",
	"voice note",
	"voice messages",
	"notas de voz",
	"nota de voz",
	"voice memos",
	"ptt",
	"statuses"
];
var recordingFolders = [
	"sound recorder",
	"soundrecorder",
	"voice recorder",
	"voicerecorder",
	"grabaciones",
	"call recordings",
	"callrecord",
	"sound_recorder",
	"recordings"
];
var recorderNames = [
	"nueva grabacion",
	"new recording",
	"audio recording",
	"voice memo",
	"nota de voz",
	"memo de voz",
	"grabacion de voz"
];
var musicExts = /* @__PURE__ */ new Set([
	"mp3",
	"m4a",
	"flac",
	"wav",
	"aac",
	"wma",
	"alac",
	"aiff",
	"aif",
	"mp4"
]);
function normalize(value) {
	return value.normalize("NFD").replace(/\p{M}+/gu, "").toLowerCase().trim();
}
function unknown(folded) {
	return folded.length === 0 || folded === "unknown" || folded === "<unknown>" || folded === "<unknown artist>" || folded === "artista desconocido";
}
function extOf(name) {
	return name.includes(".") ? name.slice(name.lastIndexOf(".") + 1) : "";
}
function folders(path) {
	return normalize(path).split(/[/\\]+/).filter((part) => part.length > 0);
}
function folderHas(path, needles) {
	return folders(path).some((folder) => needles.some((needle) => folder.includes(needle)));
}
function isMessenger(path) {
	const folded = normalize(path);
	if (folded.includes("whatsapp") || folded.includes("telegram") || folded.includes("org.thoughtcrime.securesms") || folded.includes("com.instagram.android") || folded.includes("facebook/messenger")) return true;
	return folders(path).some((folder) => folder === "signal" || folder === "messenger");
}
function classify(candidate) {
	const name = normalize(candidate.displayName);
	const artistFold = normalize(candidate.artist);
	const albumFold = normalize(candidate.album);
	const ext = extOf(name);
	const mime = normalize(candidate.mimeType);
	const unknownArtist = unknown(artistFold);
	const unknownAlbum = unknown(albumFold) || albumFold === "music";
	const hasIdentity = !unknownArtist || !unknownAlbum;
	if (voiceArtists.has(artistFold)) return "voice";
	if (candidate.isRingtone || folderHas(candidate.path, ["ringtone"])) return "other";
	if (candidate.isNotification || folderHas(candidate.path, ["notification"])) return "other";
	if (candidate.isAlarm || folderHas(candidate.path, ["alarm"])) return "other";
	if (candidate.isPodcast || folderHas(candidate.path, ["podcast"])) return "other";
	const voiceExt = ext === "opus" || ext === "amr" || ext === "3gp" || ext === "3gpp" || mime.includes("opus") || mime.includes("amr") || mime.includes("3gpp");
	const ogg = ext === "ogg" || mime.includes("ogg");
	const musicExt = musicExts.has(ext);
	const messenger = isMessenger(candidate.path);
	const voiceFolder = folderHas(candidate.path, voiceFolders);
	const recordingFolder = folderHas(candidate.path, recordingFolders);
	const pttName = name.startsWith("ptt-") || name.startsWith("ptt_") || name.startsWith("ptt ");
	const audName = audExport.test(name);
	const recorderName = recorderNames.some((label) => name.includes(label)) || name.startsWith("recording") || name.startsWith("grabacion");
	if (candidate.durationMs >= 1 && candidate.durationMs < 2e4) return voiceExt || messenger || pttName || voiceFolder || recorderName ? "voice" : "other";
	if (pttName || voiceFolder) return "voice";
	if (recorderName && !hasIdentity) return "voice";
	if (recordingFolder && (voiceExt || ogg || !hasIdentity || ext === "m4a" && unknownArtist)) return "voice";
	if (messenger && (voiceExt || ogg || pttName)) return "voice";
	if (messenger && audName && (voiceExt || ogg || !hasIdentity || candidate.durationMs >= 1 && candidate.durationMs < 75e3)) return "voice";
	if (messenger && !hasIdentity && !musicExt) return "voice";
	if (voiceExt && !hasIdentity) return "voice";
	if (ogg && !hasIdentity && candidate.durationMs < 9e4) return "voice";
	if (!candidate.isMusic && !musicExt && !(ogg && hasIdentity && candidate.durationMs >= 9e4)) return "other";
	if (candidate.sizeBytes >= 1 && candidate.sizeBytes < 4e4 && ext !== "wav" && ext !== "flac") return "other";
	return "song";
}
function item(id, title, color, candidate) {
	return {
		...candidate,
		id,
		title,
		color,
		kind: classify(candidate)
	};
}
var base = {
	album: "<unknown>",
	mimeType: "audio/mpeg",
	sizeBytes: 4e6,
	isMusic: true,
	isRingtone: false,
	isNotification: false,
	isAlarm: false,
	isPodcast: false
};
var LIBRARY = [
	item("s1", "Medianoche en el centro", "#1DB954", {
		...base,
		displayName: "medianoche.mp3",
		path: "Music/Luna Rell",
		artist: "Luna Rell",
		album: "Centro",
		durationMs: 186e3
	}),
	item("s2", "Calle 9", "#509BF5", {
		...base,
		displayName: "calle9.mp3",
		path: "Music/Los Faroles",
		artist: "Los Faroles",
		album: "Faroles",
		durationMs: 204e3
	}),
	item("s3", "Verde neón", "#E8115B", {
		...base,
		displayName: "verde.m4a",
		path: "Music/Marina Sol",
		artist: "Marina Sol",
		album: "Neón",
		durationMs: 172e3,
		mimeType: "audio/mp4"
	}),
	item("s4", "Sin mapa", "#F59B23", {
		...base,
		displayName: "sin-mapa.flac",
		path: "Download",
		artist: "Diego Alva",
		album: "Mapas",
		durationMs: 221e3,
		mimeType: "audio/flac",
		isMusic: false,
		sizeBytes: 24e6
	}),
	item("s5", "Eco", "#8D67AB", {
		...base,
		displayName: "eco.ogg",
		path: "Music/Nube Gris",
		artist: "Nube Gris",
		album: "Eco",
		durationMs: 198e3,
		mimeType: "audio/ogg"
	}),
	item("s6", "Después de las 3", "#2D46B9", {
		...base,
		displayName: "despues.mp3",
		path: "Music/RELL",
		artist: "RELL",
		album: "Noche",
		durationMs: 156e3
	}),
	item("s7", "Vidrio", "#E13300", {
		...base,
		displayName: "vidrio.mp3",
		path: "Music/Ambar Norte",
		artist: "Ambar Norte",
		album: "Vidrio",
		durationMs: 143e3
	}),
	item("s8", "Horizonte", "#148A08", {
		...base,
		displayName: "horizonte.mp3",
		path: "Music/Club Paraiso",
		artist: "Club Paraíso",
		album: "Club",
		durationMs: 21e4
	}),
	item("s9", "Baja la luz", "#1ED760", {
		...base,
		displayName: "baja.mp3",
		path: "Download",
		artist: "Vera Quin",
		album: "Luz",
		durationMs: 188e3
	}),
	item("s10", "Tecla verde", "#3D91F4", {
		...base,
		displayName: "AUD-20261101-WA0099.mp3",
		path: "WhatsApp/Media/WhatsApp Audio",
		artist: "Nico Rell",
		album: "Tecla",
		durationMs: 2e5
	}),
	item("v1", "PTT-20261112-WA0042.opus", "#333", {
		...base,
		displayName: "PTT-20261112-WA0042.opus",
		path: "WhatsApp/Media/WhatsApp Voice Notes",
		artist: "",
		album: "",
		durationMs: 18e3,
		mimeType: "audio/ogg",
		sizeBytes: 8e4
	}),
	item("v2", "PTT-20261112-WA0048.opus", "#333", {
		...base,
		displayName: "PTT-20261112-WA0048.opus",
		path: "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes",
		artist: "",
		album: "",
		durationMs: 125e3,
		mimeType: "audio/opus",
		sizeBytes: 4e5
	}),
	item("v3", "AUD-20261110-WA0011.mp3", "#333", {
		...base,
		displayName: "AUD-20261110-WA0011.mp3",
		path: "WhatsApp/Media/WhatsApp Audio",
		artist: "<unknown>",
		album: "<unknown>",
		durationMs: 55e3
	}),
	item("v4", "Nueva grabación 7.m4a", "#333", {
		...base,
		displayName: "Nueva grabación 7.m4a",
		path: "Recordings/Sound Recorder",
		artist: "<unknown>",
		album: "",
		durationMs: 48e3,
		mimeType: "audio/mp4"
	}),
	item("o1", "ringtone.mp3", "#333", {
		...base,
		displayName: "ringtone.mp3",
		path: "Ringtones",
		artist: "",
		durationMs: 8e3,
		isRingtone: true,
		isMusic: false,
		sizeBytes: 9e4
	}),
	item("o2", "episode.mp3", "#333", {
		...base,
		displayName: "episode.mp3",
		path: "Podcasts/Show",
		artist: "Show",
		album: "Daily",
		durationMs: 18e5,
		isPodcast: true
	})
];
var SONGS = LIBRARY.filter((track) => track.kind === "song");
var HIDDEN = LIBRARY.filter((track) => track.kind !== "song");
var FAV_KEY = "rells-favs";
function formatMs(ms) {
	const total = Math.max(0, Math.floor(ms / 1e3));
	return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}
function greeting() {
	const hour = (/* @__PURE__ */ new Date()).getHours();
	if (hour >= 5 && hour < 12) return "Buenos días";
	if (hour >= 12 && hour < 20) return "Buenas tardes";
	return "Buenas noches";
}
function Cover({ track, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `grid shrink-0 place-items-center font-bold text-white ${className ?? ""}`,
		style: { background: `linear-gradient(145deg, ${track.color}, #121212 140%)` },
		children: track.title.trim().slice(0, 1).toUpperCase()
	});
}
function RellsApp() {
	const [tab, setTab] = (0, import_react.useState)("home");
	const [query, setQuery] = (0, import_react.useState)("");
	const [hello, setHello] = (0, import_react.useState)("Hoy");
	const [favs, setFavs] = (0, import_react.useState)([]);
	const [currentId, setCurrentId] = (0, import_react.useState)(null);
	const [queue, setQueue] = (0, import_react.useState)(SONGS.map((song) => song.id));
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [position, setPosition] = (0, import_react.useState)(0);
	const [shuffle, setShuffle] = (0, import_react.useState)(false);
	const [repeat, setRepeat] = (0, import_react.useState)("off");
	const [nowOpen, setNowOpen] = (0, import_react.useState)(false);
	const [hiddenOpen, setHiddenOpen] = (0, import_react.useState)(false);
	const [lib, setLib] = (0, import_react.useState)("songs");
	const model = (0, import_react.useRef)({
		queue,
		repeat,
		shuffle,
		currentId
	});
	model.current = {
		queue,
		repeat,
		shuffle,
		currentId
	};
	(0, import_react.useEffect)(() => {
		setHello(greeting());
		try {
			const saved = JSON.parse(localStorage.getItem(FAV_KEY) || "[]");
			if (Array.isArray(saved)) setFavs(saved);
		} catch {}
	}, []);
	const current = SONGS.find((song) => song.id === currentId) ?? null;
	(0, import_react.useEffect)(() => {
		if (!playing || !current) return;
		const id = window.setInterval(() => {
			setPosition((pos) => {
				const next = pos + 500;
				if (next >= current.durationMs) return current.durationMs;
				return next;
			});
		}, 500);
		return () => window.clearInterval(id);
	}, [playing, current]);
	(0, import_react.useEffect)(() => {
		if (current && position >= current.durationMs && playing) {
			if (repeat === "one") {
				setPosition(0);
				return;
			}
			const list = model.current.queue;
			const index = list.indexOf(current.id);
			if (shuffle) {
				const options = list.filter((id) => id !== current.id);
				const pick = options[Math.floor(Math.random() * options.length)] ?? current.id;
				setCurrentId(pick);
				setPosition(0);
				return;
			}
			if (index >= 0 && index < list.length - 1) {
				setCurrentId(list[index + 1] ?? null);
				setPosition(0);
				return;
			}
			if (repeat === "all" && list.length > 0) {
				setCurrentId(list[0] ?? null);
				setPosition(0);
				return;
			}
			setPlaying(false);
		}
	}, [
		position,
		current,
		playing,
		repeat,
		shuffle
	]);
	function toggleFav(id) {
		setFavs((prev) => {
			const next = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
			localStorage.setItem(FAV_KEY, JSON.stringify(next));
			return next;
		});
	}
	function playTrack(id, nextQueue) {
		setQueue(nextQueue);
		setCurrentId(id);
		setPosition(0);
		setPlaying(true);
	}
	function toggle() {
		if (!current) {
			const first = SONGS[0];
			if (first) playTrack(first.id, SONGS.map((song) => song.id));
			return;
		}
		if (!playing && position >= current.durationMs) setPosition(0);
		setPlaying((value) => !value);
	}
	function skip(direction) {
		if (!current) return;
		if (direction < 0 && position > 3e3) {
			setPosition(0);
			return;
		}
		const list = queue.length ? queue : SONGS.map((song) => song.id);
		const next = list[(list.indexOf(current.id) + direction + list.length) % list.length];
		if (next) {
			setCurrentId(next);
			setPosition(0);
			setPlaying(true);
		}
	}
	const results = (0, import_react.useMemo)(() => {
		const needle = normalize(query);
		if (!needle) return SONGS;
		return SONGS.filter((song) => [
			song.title,
			song.artist,
			song.album
		].some((value) => normalize(value).includes(needle)));
	}, [query]);
	const liked = SONGS.filter((song) => favs.includes(song.id));
	const albums = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const song of SONGS) {
			const key = song.album || song.title;
			map.set(key, [...map.get(key) ?? [], song]);
		}
		return [...map.entries()];
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto flex h-dvh max-w-[430px] flex-col overflow-hidden bg-[#121212] text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-0 top-0 h-64 bg-gradient-to-b from-[#1b4332] to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative z-10 min-h-0 flex-1 overflow-y-auto pb-4",
				children: [
					tab === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-4 pt-5 text-[13px] font-bold tracking-[0.16em] text-[#1DB954]",
							children: "RELL'S LIFE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "px-4 pt-2 text-[28px] font-bold",
							children: hello
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-4 pb-4 pt-1 text-[13px] text-[#b3b3b3]",
							children: "Vista previa. En el celular suena tu música y se ocultan los audios."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setHiddenOpen(true),
							className: "mx-4 mb-4 block rounded-lg bg-[#18241c] px-3 py-3 text-left text-[13px] text-[#b3b3b3]",
							children: [
								"Detector: se ocultaron ",
								HIDDEN.filter((item) => item.kind === "voice").length,
								" audios y",
								" ",
								HIDDEN.filter((item) => item.kind === "other").length,
								" archivos que no son canciones."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2 px-4",
							children: [
								{
									title: "Tus me gusta",
									songs: liked.length ? liked : SONGS.slice(0, 4),
									color: "#3a1d4a"
								},
								{
									title: albums[0]?.[0] ?? "Centro",
									songs: albums[0]?.[1] ?? SONGS,
									color: SONGS[0]?.color ?? "#1DB954"
								},
								{
									title: albums[1]?.[0] ?? "Faroles",
									songs: albums[1]?.[1] ?? SONGS,
									color: SONGS[1]?.color ?? "#509BF5"
								},
								{
									title: albums[2]?.[0] ?? "Neón",
									songs: albums[2]?.[1] ?? SONGS,
									color: SONGS[2]?.color ?? "#E8115B"
								}
							].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									const first = card.songs[0];
									if (first) playTrack(first.id, card.songs.map((song) => song.id));
								},
								className: "flex h-14 items-center overflow-hidden rounded bg-[#2a2a2a] text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "h-14 w-14 shrink-0",
									style: { background: card.color }
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-2 text-[13px] font-bold leading-tight",
									children: card.title
								})]
							}, card.title))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "px-4 pb-3 pt-6 text-[20px] font-bold",
							children: "Hecho para ti"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "no-scrollbar flex gap-3 overflow-x-auto px-4",
							children: SONGS.slice(0, 8).map((song) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => playTrack(song.id, SONGS.map((item) => item.id)),
								className: "w-[132px] shrink-0 text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
										track: song,
										className: "h-[132px] w-[132px] rounded-md text-[36px]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate pt-2 text-[13px]",
										children: song.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-[12px] text-[#b3b3b3]",
										children: song.artist
									})
								]
							}, song.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "px-4 pb-2 pt-6 text-[20px] font-bold",
							children: "Canciones"
						}),
						SONGS.map((song) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SongRow, {
							song,
							active: song.id === currentId,
							fav: favs.includes(song.id),
							onPlay: () => playTrack(song.id, SONGS.map((item) => item.id)),
							onFav: () => toggleFav(song.id)
						}, song.id))
					] }),
					tab === "search" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: query,
							onChange: (event) => setQuery(event.target.value),
							placeholder: "¿Qué quieres escuchar?",
							className: "mx-4 mb-3 w-[calc(100%-2rem)] rounded-full bg-[#242424] px-4 py-3 text-[15px] outline-none"
						}), results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "px-6 text-[#b3b3b3]",
							children: [
								"Nada coincide con “",
								query,
								"”."
							]
						}) : results.map((song) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SongRow, {
							song,
							active: song.id === currentId,
							fav: favs.includes(song.id),
							onPlay: () => playTrack(song.id, results.map((item) => item.id)),
							onFav: () => toggleFav(song.id)
						}, song.id))]
					}),
					tab === "library" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "px-4 text-[26px] font-bold",
								children: "Biblioteca"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "no-scrollbar flex gap-2 overflow-x-auto px-4 py-3",
								children: [
									["songs", "Canciones"],
									["artists", "Artistas"],
									["liked", "Me gusta"]
								].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setLib(id),
									className: `rounded-full px-3.5 py-2 text-[13px] font-semibold ${lib === id ? "bg-[#1DB954] text-black" : "bg-[#2a2a2a]"}`,
									children: label
								}, id))
							}),
							lib === "artists" ? [...new Set(SONGS.map((song) => song.artist))].map((artist) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									const list = SONGS.filter((song) => song.artist === artist);
									const first = list[0];
									if (first) playTrack(first.id, list.map((song) => song.id));
								},
								className: "flex w-full items-center gap-3 px-4 py-2 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-12 w-12 place-items-center rounded-full font-bold",
									style: { background: "#1DB954" },
									children: artist.slice(0, 1)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: artist
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[13px] text-[#b3b3b3]",
									children: [SONGS.filter((song) => song.artist === artist).length, " canciones"]
								})] })]
							}, artist)) : (lib === "liked" ? liked : SONGS).map((song) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SongRow, {
								song,
								active: song.id === currentId,
								fav: favs.includes(song.id),
								onPlay: () => playTrack(song.id, (lib === "liked" ? liked : SONGS).map((item) => item.id)),
								onFav: () => toggleFav(song.id)
							}, song.id)),
							lib === "liked" && liked.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-4 text-[#b3b3b3]",
								children: "Todavía no marcas me gusta."
							})
						]
					})
				]
			}),
			current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setNowOpen(true),
				className: "relative z-20 flex h-16 w-full items-center gap-2 bg-[#181818] px-2 text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
						track: current,
						className: "h-12 w-12 rounded text-[16px]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-[14px] font-medium",
							children: current.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-[12px] text-[#b3b3b3]",
							children: current.artist
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						role: "button",
						tabIndex: 0,
						onClick: (event) => {
							event.stopPropagation();
							toggleFav(current.id);
						},
						onKeyDown: (event) => {
							if (event.key === "Enter") {
								event.stopPropagation();
								toggleFav(current.id);
							}
						},
						className: "grid h-11 w-11 place-items-center",
						"aria-label": "Favorito",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { on: favs.includes(current.id) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						role: "button",
						tabIndex: 0,
						onClick: (event) => {
							event.stopPropagation();
							toggle();
						},
						onKeyDown: (event) => {
							if (event.key === "Enter") {
								event.stopPropagation();
								toggle();
							}
						},
						className: "grid h-11 w-11 place-items-center",
						"aria-label": playing ? "Pausar" : "Reproducir",
						children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "relative z-20 grid grid-cols-3 bg-black pb-2 pt-2 text-[11px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
						label: "Inicio",
						active: tab === "home",
						onClick: () => setTab("home"),
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeIcon, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
						label: "Buscar",
						active: tab === "search",
						onClick: () => setTab("search"),
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchIcon, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
						label: "Biblioteca",
						active: tab === "library",
						onClick: () => setTab("library"),
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibIcon, {})
					})
				]
			}),
			nowOpen && current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 z-30 flex flex-col bg-gradient-to-b from-[#1b4332] to-[#121212] px-5 pb-6 pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Cerrar",
								onClick: () => setNowOpen(false),
								className: "grid h-11 w-11 place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chevron, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] tracking-[0.14em] text-[#b3b3b3]",
									children: "REPRODUCIENDO"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[13px] font-bold",
									children: "Tu biblioteca"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-11" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
						track: current,
						className: "mt-6 aspect-square w-full rounded-lg text-[72px]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-[22px] font-bold",
								children: current.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-[15px] text-[#b3b3b3]",
								children: current.artist
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Favorito",
							onClick: () => toggleFav(current.id),
							className: "grid h-11 w-11 place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { on: favs.includes(current.id) })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						"aria-label": "Posición",
						type: "range",
						min: 0,
						max: current.durationMs,
						value: Math.min(position, current.durationMs),
						onChange: (event) => setPosition(Number(event.target.value)),
						className: "mt-4 w-full accent-[#1DB954]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-[12px] text-[#b3b3b3]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatMs(position) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatMs(current.durationMs) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between px-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Aleatorio",
								onClick: () => setShuffle((value) => !value),
								className: shuffle ? "text-[#1DB954]" : "text-[#b3b3b3]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShuffleIcon, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Anterior",
								onClick: () => skip(-1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skip, { dir: "prev" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": playing ? "Pausar" : "Reproducir",
								onClick: toggle,
								className: "grid h-16 w-16 place-items-center rounded-full bg-[#1DB954] text-black",
								children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Siguiente",
								onClick: () => skip(1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skip, { dir: "next" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Repetir",
								onClick: () => setRepeat((value) => value === "off" ? "all" : value === "all" ? "one" : "off"),
								className: repeat === "off" ? "text-[#b3b3b3]" : "text-[#1DB954]",
								children: repeat === "one" ? "1" : "↺"
							})
						]
					})
				]
			}),
			hiddenOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 z-40 overflow-y-auto bg-[#121212] px-4 pb-8 pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setHiddenOpen(false),
						className: "text-[14px] font-semibold text-[#1DB954]",
						children: "Cerrar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "pt-3 text-[24px] font-bold",
						children: "Fuera de la biblioteca"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pb-4 pt-1 text-[14px] text-[#b3b3b3]",
						children: "El detector no trata estos archivos como canciones."
					}),
					HIDDEN.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-b border-white/10 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: item.displayName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[13px] text-[#b3b3b3]",
							children: [
								item.kind === "voice" ? "Audio o nota de voz" : "Tono, podcast o clip",
								" · ",
								item.path
							]
						})]
					}, item.id))
				]
			})
		]
	});
}
function SongRow({ song, active, fav, onPlay, onFav }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 px-3 py-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onPlay,
				className: "flex min-w-0 flex-1 items-center gap-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
					track: song,
					className: "h-12 w-12 rounded text-[16px]"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `block truncate text-[15px] font-medium ${active ? "text-[#1DB954]" : ""}`,
						children: song.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-[13px] text-[#b3b3b3]",
						children: song.artist
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[12px] text-[#b3b3b3]",
				children: formatMs(song.durationMs)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Favorito",
				onClick: onFav,
				className: "grid h-11 w-11 place-items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { on: fav })
			})
		]
	});
}
function NavButton({ label, active, onClick, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: `grid justify-items-center gap-1 ${active ? "text-white" : "text-[#b3b3b3]"}`,
		children: [icon, label]
	});
}
function Heart({ on }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "22",
		height: "22",
		viewBox: "0 0 24 24",
		fill: on ? "#1DB954" : "none",
		stroke: on ? "#1DB954" : "#b3b3b3",
		strokeWidth: "2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 20s-7-4.4-7-9a4 4 0 0 1 7-2 4 4 0 0 1 7 2c0 4.6-7 9-7 9z" })
	});
}
function Play() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "28",
		height: "28",
		viewBox: "0 0 24 24",
		fill: "currentColor",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 5v14l11-7z" })
	});
}
function Pause() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "28",
		height: "28",
		viewBox: "0 0 24 24",
		fill: "currentColor",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6 5h4v14H6zM14 5h4v14h-4z" })
	});
}
function HomeIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "22",
		height: "22",
		viewBox: "0 0 24 24",
		fill: "currentColor",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 4 3 11h2v8h5v-5h4v5h5v-8h2z" })
	});
}
function SearchIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "22",
		height: "22",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "11",
			cy: "11",
			r: "7"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m20 20-3.5-3.5" })]
	});
}
function LibIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "22",
		height: "22",
		viewBox: "0 0 24 24",
		fill: "currentColor",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 5h2v14H4zM8 5h12v2H8zM8 11h12v2H8zM8 17h12v2H8z" })
	});
}
function Chevron() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "28",
		height: "28",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "white",
		strokeWidth: "2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m6 9 6 6 6-6" })
	});
}
function Skip({ dir }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "34",
		height: "34",
		viewBox: "0 0 24 24",
		fill: "white",
		style: { transform: dir === "prev" ? "scaleX(-1)" : void 0 },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6 5v14h2V5zm3 7 9 6V6z" })
	});
}
function ShuffleIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "22",
		height: "22",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m16 3 4 4-4 4" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 7h11l5 0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m16 17 4 4-4 0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 17h2l9 7" })
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RellsApp, {});
}
//#endregion
export { Home as component };
