package com.rellslife.music.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import com.rellslife.music.FavoritesStore
import com.rellslife.music.LibraryEditsStore
import com.rellslife.music.MusicFilter
import com.rellslife.music.MusicLibrary
import com.rellslife.music.Playlist
import com.rellslife.music.PlayerController
import com.rellslife.music.QueueTrack
import com.rellslife.music.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

private enum class Tab { HOME, SEARCH, LIBRARY }
private enum class LibView { SONGS, ARTISTS, ALBUMS, PLAYLISTS }
private enum class LibrarySort { DEFAULT, AZ, DURATION, RECENT }

private fun sortTracks(tracks: List<Track>, sort: LibrarySort, recents: List<Long>): List<Track> = when (sort) {
    LibrarySort.DEFAULT -> tracks
    LibrarySort.AZ -> tracks.sortedBy { it.title.lowercase() }
    LibrarySort.DURATION -> tracks.sortedBy { it.durationMs }
    LibrarySort.RECENT -> tracks.sortedBy { track -> recents.indexOf(track.id).let { if (it < 0) Int.MAX_VALUE else it } }
}

private class LibraryState {
    var tracks by mutableStateOf<List<Track>>(emptyList())
    var hiddenVoice by mutableIntStateOf(0)
    var hiddenOther by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var hasAudioPermission by mutableStateOf(false)
    var scanTick by mutableIntStateOf(0)
}

@Composable
fun RellsApp(player: PlayerController) {
    val context = LocalContext.current
    val library = remember { LibraryState() }
    val favorites = remember { FavoritesStore(context.applicationContext) }
    val edits = remember { LibraryEditsStore(context.applicationContext) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    var nowOpen by remember { mutableStateOf(false) }
    var queueOpen by remember { mutableStateOf(false) }
    val audioPermission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        library.hasAudioPermission =
            ContextCompat.checkSelfPermission(context, audioPermission) == android.content.pm.PackageManager.PERMISSION_GRANTED
        library.scanTick++
    }
    LaunchedEffect(Unit) {
        val granted =
            ContextCompat.checkSelfPermission(context, audioPermission) == android.content.pm.PackageManager.PERMISSION_GRANTED
        library.hasAudioPermission = granted
        val missing = buildList {
            if (!granted) add(audioPermission)
            if (
                Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (missing.isNotEmpty()) launcher.launch(missing.toTypedArray())
    }
    LaunchedEffect(library.hasAudioPermission, library.scanTick) {
        if (!library.hasAudioPermission) {
            library.loading = false
            library.tracks = emptyList()
            return@LaunchedEffect
        }
        library.loading = true
        val scan = withContext(Dispatchers.IO) { MusicLibrary.scan(context.contentResolver) }
        library.tracks = scan.songs
        library.hiddenVoice = scan.hiddenVoice
        library.hiddenOther = scan.hiddenOther
        library.loading = false
    }
    fun play(list: List<Track>, index: Int) {
        if (list.isEmpty()) return
        val safe = index.coerceIn(0, list.lastIndex)
        player.playAll(list, safe)
        favorites.pushRecent(list[safe].id)
    }
    BackHandler(enabled = nowOpen) { nowOpen = false }
    BackHandler(enabled = queueOpen) { queueOpen = false }
    Box(Modifier.fillMaxSize().background(Bg)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                Column {
                    if (player.hasTrack) MiniPlayer(player, favorites) { nowOpen = true }
                    NavBar(tab) { tab = it }
                }
            },
        ) { padding ->
            when (tab) {
                Tab.HOME -> HomeScreen(padding, library, favorites, edits, player, ::play) { tab = Tab.LIBRARY }
                Tab.SEARCH -> SearchScreen(padding, library, favorites, edits, player, ::play)
                Tab.LIBRARY -> LibraryScreen(padding, library, favorites, edits, player, ::play)
            }
        }
        if (nowOpen && player.hasTrack) {
            NowPlaying(player, favorites, onOpenQueue = { queueOpen = true }) { nowOpen = false }
        }
        if (queueOpen && player.hasTrack) QueueSheet(player) { queueOpen = false }
    }
}

@Composable
private fun NavBar(tab: Tab, onSelect: (Tab) -> Unit) {
    val colors = NavigationBarItemDefaults.colors(
        selectedIconColor = Color.White,
        selectedTextColor = Color.White,
        unselectedIconColor = Muted,
        unselectedTextColor = Muted,
        indicatorColor = Color.Transparent,
    )
    NavigationBar(containerColor = Color.Black) {
        NavigationBarItem(
            selected = tab == Tab.HOME,
            onClick = { onSelect(Tab.HOME) },
            colors = colors,
            icon = { Icon(Icons.Filled.Home, contentDescription = null) },
            label = { Text("Inicio") },
        )
        NavigationBarItem(
            selected = tab == Tab.SEARCH,
            onClick = { onSelect(Tab.SEARCH) },
            colors = colors,
            icon = { Icon(Icons.Filled.Search, contentDescription = null) },
            label = { Text("Buscar") },
        )
        NavigationBarItem(
            selected = tab == Tab.LIBRARY,
            onClick = { onSelect(Tab.LIBRARY) },
            colors = colors,
            icon = { Icon(Icons.Filled.LibraryMusic, contentDescription = null) },
            label = { Text("Biblioteca") },
        )
    }
}

@Composable
private fun HomeScreen(
    padding: PaddingValues,
    library: LibraryState,
    favorites: FavoritesStore,
    edits: LibraryEditsStore,
    player: PlayerController,
    play: (List<Track>, Int) -> Unit,
    openLibrary: () -> Unit,
) {
    val tracks = library.tracks.filter { !edits.isRemoved(it.id) }
    val recent = favorites.recents.mapNotNull { id -> tracks.find { it.id == id } }
    val added = remember(tracks) { tracks.sortedByDescending { it.dateAdded }.take(12) }
    val albums = remember(tracks) { albumGroups(tracks).take(8) }
    val liked = tracks.filter { favorites.isFavorite(it.id) }
    Box(Modifier.fillMaxSize().padding(padding)) {
        Box(Modifier.fillMaxWidth().height(260.dp).background(Brush.verticalGradient(listOf(Color(0xFF1B4332), Bg))))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            item {
                Text("RELL'S LIFE", color = Green, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, top = 18.dp))
                Text(greeting(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp, modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 16.dp))
            }
            when {
                !library.hasAudioPermission -> item { PermissionNote() }
                library.loading && tracks.isEmpty() -> item { LoadingNote() }
                tracks.isEmpty() -> item { EmptyNote(library) }
                else -> {
                    if (library.hiddenVoice + library.hiddenOther > 0) item { DetectorNote(library) }
                    item {
                        ShortcutGrid(
                            buildList {
                                if (liked.isNotEmpty()) add(Shortcut("Tus me gusta", "likes", null, liked))
                                if (recent.isNotEmpty()) add(Shortcut("Recientes", recent.first().title, recent.first().albumArtUri, recent))
                                albums.take(4).forEach { add(Shortcut(it.name, it.name, it.art, it.tracks)) }
                            },
                            play,
                        )
                    }
                    if (recent.isNotEmpty()) {
                        item { SectionTitle("Escuchado reciente") }
                        item { TrackRow(recent, play) }
                    }
                    if (added.isNotEmpty()) {
                        item { SectionTitle("Añadidas hace poco") }
                        item { TrackRow(added, play) }
                    }
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Canciones", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text("Ver todas", color = Muted, fontSize = 13.sp, modifier = Modifier.clickable(onClick = openLibrary))
                        }
                    }
                    items(tracks.take(12), key = { it.id }) { track ->
                        SongRow(track, player, favorites, edits) { play(tracks, tracks.indexOf(track)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchScreen(
    padding: PaddingValues,
    library: LibraryState,
    favorites: FavoritesStore,
    edits: LibraryEditsStore,
    player: PlayerController,
    play: (List<Track>, Int) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val baseTracks = library.tracks.filter { !edits.isRemoved(it.id) }
    val results = remember(query, baseTracks) {
        val needle = MusicFilter.normalize(query)
        if (needle.isBlank()) baseTracks
        else baseTracks.filter {
            MusicFilter.normalize(it.title).contains(needle) ||
                MusicFilter.normalize(it.artist).contains(needle) ||
                MusicFilter.normalize(it.album).contains(needle)
        }
    }
    Column(Modifier.fillMaxSize().padding(padding)) {
        TextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            placeholder = { Text("¿Qué quieres escuchar?", color = Muted) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Muted) },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF242424),
                unfocusedContainerColor = Color(0xFF242424),
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = Green,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
            ),
        )
        LazyColumn(Modifier.weight(1f)) {
            if (results.isEmpty()) {
                item { Text(if (query.isBlank()) "Tu música aparece aquí." else "Nada coincide con “$query”.", color = Muted, modifier = Modifier.padding(24.dp)) }
            } else {
                items(results, key = { it.id }) { track ->
                    SongRow(track, player, favorites, edits) { play(results, results.indexOf(track)) }
                }
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    padding: PaddingValues,
    library: LibraryState,
    favorites: FavoritesStore,
    edits: LibraryEditsStore,
    player: PlayerController,
    play: (List<Track>, Int) -> Unit,
) {
    var view by remember { mutableStateOf(LibView.SONGS) }
    var likedOnly by remember { mutableStateOf(false) }
    var artist by remember { mutableStateOf<String?>(null) }
    var albumKey by remember { mutableStateOf<String?>(null) }
    var selectedPlaylist by remember { mutableStateOf<String?>(null) }
    var sort by remember { mutableStateOf(LibrarySort.DEFAULT) }
    var createPlaylistOpen by remember { mutableStateOf(false) }
    val tracks = library.tracks.filter { !edits.isRemoved(it.id) }
    val albums = remember(tracks) { albumGroups(tracks) }
    BackHandler(enabled = artist != null || albumKey != null || selectedPlaylist != null) {
        artist = null
        albumKey = null
        selectedPlaylist = null
    }
    Column(Modifier.fillMaxSize().padding(padding)) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Biblioteca", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 26.sp, modifier = Modifier.weight(1f))
            Text("Actualizar", color = Green, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { library.scanTick++ }.padding(8.dp))
        }
        if (library.hiddenVoice + library.hiddenOther > 0) DetectorNote(library)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Canciones", view == LibView.SONGS && !likedOnly && artist == null && albumKey == null) {
                view = LibView.SONGS; likedOnly = false; artist = null; albumKey = null; selectedPlaylist = null
            }
            Chip("Artistas", view == LibView.ARTISTS && artist == null) {
                view = LibView.ARTISTS; likedOnly = false; artist = null; albumKey = null; selectedPlaylist = null
            }
            Chip("Álbumes", view == LibView.ALBUMS && albumKey == null) {
                view = LibView.ALBUMS; likedOnly = false; artist = null; albumKey = null; selectedPlaylist = null
            }
            Chip("Me gusta", likedOnly) {
                view = LibView.SONGS; likedOnly = true; artist = null; albumKey = null; selectedPlaylist = null
            }
            Chip("Listas", view == LibView.PLAYLISTS && selectedPlaylist == null) {
                view = LibView.PLAYLISTS; likedOnly = false; artist = null; albumKey = null; selectedPlaylist = null
            }
        }
        when {
            artist != null -> {
                val list = tracks.filter { it.artist == artist }
                DrillHeader(artist ?: "", "${list.size} canciones") { artist = null }
                SongList(list, player, favorites, edits, play, Modifier.weight(1f))
            }
            albumKey != null -> {
                val group = albums.find { it.key == albumKey }
                DrillHeader(group?.name ?: "Álbum", group?.artist ?: "") { albumKey = null }
                SongList(group?.tracks.orEmpty(), player, favorites, edits, play, Modifier.weight(1f))
            }
            selectedPlaylist != null -> {
                val playlist = edits.playlists.find { it.id == selectedPlaylist }
                if (playlist == null) {
                    selectedPlaylist = null
                } else {
                    val playlistTracks = playlist.trackIds.mapNotNull { id -> tracks.find { it.id == id } }
                    DrillHeader(
                        title = playlist.name,
                        subtitle = "${playlistTracks.size} canciones",
                        trailing = {
                            Text(
                                "Eliminar lista",
                                color = Color(0xFFE13300),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                modifier = Modifier.clickable {
                                    edits.deletePlaylist(playlist.id)
                                    selectedPlaylist = null
                                },
                            )
                        },
                        onBack = { selectedPlaylist = null },
                    )
                    if (playlistTracks.isEmpty()) {
                        Text(
                            "Agrega canciones desde el menú “⋮” de cualquier canción.",
                            color = Muted,
                            modifier = Modifier.padding(16.dp),
                        )
                    } else {
                        LazyColumn(Modifier.weight(1f)) {
                            items(playlistTracks, key = { it.id }) { track ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.weight(1f)) {
                                        SongRow(track, player, favorites, edits) { play(playlistTracks, playlistTracks.indexOf(track)) }
                                    }
                                    IconButton(onClick = { edits.removeTrack(playlist.id, track.id) }) {
                                        Icon(Icons.Filled.Close, contentDescription = "Quitar de la lista", tint = Muted)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            view == LibView.PLAYLISTS -> {
                Column(Modifier.weight(1f)) {
                    Text(
                        "+ Crear lista de reproducción",
                        color = Green,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF2A2A2A))
                            .clickable { createPlaylistOpen = true }
                            .padding(16.dp),
                    )
                    if (edits.playlists.isEmpty()) {
                        Text("Todavía no tienes listas.", color = Muted, modifier = Modifier.padding(16.dp))
                    } else {
                        LazyColumn(Modifier.weight(1f)) {
                            items(edits.playlists, key = { it.id }) { playlist ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { selectedPlaylist = playlist.id }.padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A2A2A)), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.QueueMusic, contentDescription = null, tint = Muted)
                                    }
                                    Column(Modifier.padding(start = 12.dp)) {
                                        Text(playlist.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("${playlist.trackIds.size} canciones", color = Muted, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            view == LibView.ARTISTS -> {
                val artists = tracks.groupBy { it.artist }.entries.sortedBy { it.key.lowercase() }
                LazyColumn(Modifier.weight(1f)) {
                    items(artists, key = { it.key }) { entry ->
                        Row(
                            Modifier.fillMaxWidth().clickable { artist = entry.key }.padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            LetterBubble(entry.key)
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(entry.key, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${entry.value.size} canciones", color = Muted, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
            view == LibView.ALBUMS -> {
                LazyColumn(Modifier.weight(1f)) {
                    items(albums, key = { it.key }) { group ->
                        Row(
                            Modifier.fillMaxWidth().clickable { albumKey = group.key }.padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CoverArt(group.art, group.name, Modifier.size(56.dp), letterSize = 20.sp)
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(group.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(group.artist, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            else -> {
                val base = if (likedOnly) tracks.filter { favorites.isFavorite(it.id) } else tracks
                val shown = sortTracks(base, sort, favorites.recents)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Predeterminado", sort == LibrarySort.DEFAULT) { sort = LibrarySort.DEFAULT }
                    Chip("A-Z", sort == LibrarySort.AZ) { sort = LibrarySort.AZ }
                    Chip("Duración", sort == LibrarySort.DURATION) { sort = LibrarySort.DURATION }
                    Chip("Recientes", sort == LibrarySort.RECENT) { sort = LibrarySort.RECENT }
                }
                if (shown.isEmpty()) {
                    Text(
                        if (likedOnly) "Todavía no marcas me gusta." else "No hay canciones para mostrar.",
                        color = Muted,
                        modifier = Modifier.padding(16.dp),
                    )
                } else {
                    SongList(shown, player, favorites, edits, play, Modifier.weight(1f))
                }
            }
        }
    }
    if (createPlaylistOpen) {
        CreatePlaylistDialog(edits) { createPlaylistOpen = false }
    }
}

@Composable
private fun SongList(
    tracks: List<Track>,
    player: PlayerController,
    favorites: FavoritesStore,
    edits: LibraryEditsStore,
    play: (List<Track>, Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(modifier) {
        items(tracks, key = { it.id }) { track ->
            SongRow(track, player, favorites, edits) { play(tracks, tracks.indexOf(track)) }
        }
    }
}

@Composable
private fun DrillHeader(
    title: String,
    subtitle: String,
    trailing: (@Composable () -> Unit)? = null,
    onBack: () -> Unit,
) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Volver", color = Green, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable(onClick = onBack))
            trailing?.invoke()
        }
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 24.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (subtitle.isNotBlank()) Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun SongRow(track: Track, player: PlayerController, favorites: FavoritesStore, edits: LibraryEditsStore, onPlay: () -> Unit) {
    val current = player.mediaId == track.id.toString()
    var menuOpen by remember { mutableStateOf(false) }
    var addToPlaylistOpen by remember { mutableStateOf(false) }
    var deleteConfirmOpen by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onPlay).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CoverArt(track.albumArtUri, track.title, Modifier.size(48.dp), letterSize = 16.sp)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(track.title, color = if (current) Green else Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
            Text(track.artist, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(formatMs(track.durationMs), color = Muted, fontSize = 12.sp)
        IconButton(onClick = { favorites.toggle(track.id) }) {
            Icon(
                if (favorites.isFavorite(track.id)) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = "Favorito",
                tint = if (favorites.isFavorite(track.id)) Green else Muted,
            )
        }
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Más opciones", tint = Muted)
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("Agregar a lista de reproducción") },
                    onClick = { menuOpen = false; addToPlaylistOpen = true },
                )
                DropdownMenuItem(
                    text = { Text("Eliminar de tu biblioteca") },
                    onClick = { menuOpen = false; deleteConfirmOpen = true },
                )
            }
        }
    }
    if (addToPlaylistOpen) {
        AddToPlaylistDialog(edits, track.id) { addToPlaylistOpen = false }
    }
    if (deleteConfirmOpen) {
        AlertDialog(
            onDismissRequest = { deleteConfirmOpen = false },
            title = { Text("Eliminar canción") },
            text = { Text("“${track.title}” se quitará de Rell's Life. No se borra del celular.") },
            confirmButton = {
                TextButton(onClick = {
                    edits.remove(track.id)
                    player.removeTrackId(track.id)
                    deleteConfirmOpen = false
                }) { Text("Eliminar", color = Color(0xFFE13300)) }
            },
            dismissButton = {
                TextButton(onClick = { deleteConfirmOpen = false }) { Text("Cancelar") }
            },
        )
    }
}

@Composable
private fun MiniPlayer(player: PlayerController, favorites: FavoritesStore, onOpen: () -> Unit) {
    val id = player.mediaId?.toLongOrNull()
    Row(
        Modifier.fillMaxWidth().height(64.dp).background(Surface).clickable(onClick = onOpen).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CoverArt(player.artUri, player.title, Modifier.size(48.dp), letterSize = 16.sp)
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(player.title.ifBlank { "Sin título" }, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            Text(player.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (id != null) {
            IconButton(onClick = { favorites.toggle(id) }) {
                Icon(
                    if (favorites.isFavorite(id)) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorito",
                    tint = if (favorites.isFavorite(id)) Green else Color.White,
                )
            }
        }
        IconButton(onClick = player::toggle) {
            Icon(
                if (player.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = "Reproducir",
                tint = Color.White,
            )
        }
    }
}

@Composable
private fun NowPlaying(player: PlayerController, favorites: FavoritesStore, onOpenQueue: () -> Unit, onClose: () -> Unit) {
    var dragging by remember { mutableStateOf(false) }
    var drag by remember { mutableFloatStateOf(0f) }
    val fraction = if (player.duration > 0) (player.position.toFloat() / player.duration.toFloat()).coerceIn(0f, 1f) else 0f
    val id = player.mediaId?.toLongOrNull()
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B4332), Bg)))
            .windowInsetsPadding(WindowInsets.systemBars)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Cerrar", tint = Color.White)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("REPRODUCIENDO", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
                Text("Tu biblioteca", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            IconButton(onClick = onOpenQueue) {
                Icon(Icons.Filled.QueueMusic, contentDescription = "Ver cola", tint = Color.White)
            }
        }
        CoverArt(
            player.artUri,
            player.title,
            Modifier.padding(top = 28.dp).fillMaxWidth().aspectRatio(1f),
            corner = 8.dp,
            letterSize = 72.sp,
        )
        Row(Modifier.padding(top = 24.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(player.title.ifBlank { "Sin título" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(player.artist.ifBlank { "Artista desconocido" }, color = Muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (id != null) {
                IconButton(onClick = { favorites.toggle(id) }) {
                    Icon(
                        if (favorites.isFavorite(id)) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "Favorito",
                        tint = if (favorites.isFavorite(id)) Green else Muted,
                    )
                }
            }
        }
        Slider(
            value = if (dragging) drag else fraction,
            onValueChange = { dragging = true; drag = it },
            onValueChangeFinished = {
                player.seekTo((drag * player.duration).toLong())
                dragging = false
            },
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Green,
                inactiveTrackColor = Color(0xFF4D4D4D),
            ),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatMs(if (dragging) (drag * player.duration).toLong() else player.position), color = Muted, fontSize = 12.sp)
            Text(formatMs(player.duration), color = Muted, fontSize = 12.sp)
        }
        player.error?.let {
            Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        }
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { player.setVolume(if (player.volume > 0f) 0f else 1f) }) {
                Icon(
                    when {
                        player.volume <= 0f -> Icons.Filled.VolumeOff
                        player.volume < 0.5f -> Icons.Filled.VolumeDown
                        else -> Icons.Filled.VolumeUp
                    },
                    contentDescription = if (player.volume <= 0f) "Activar sonido" else "Silenciar",
                    tint = Color.White,
                )
            }
            Slider(
                value = player.volume,
                onValueChange = { player.setVolume(it) },
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Green,
                    inactiveTrackColor = Color(0xFF4D4D4D),
                ),
                modifier = Modifier.weight(1f),
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 28.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = player::toggleShuffle) {
                Icon(Icons.Filled.Shuffle, contentDescription = "Aleatorio", tint = if (player.shuffle) Green else Muted)
            }
            IconButton(onClick = player::previous) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Anterior", tint = Color.White, modifier = Modifier.size(40.dp))
            }
            Box(
                Modifier.size(68.dp).clip(CircleShape).background(Green).clickable(onClick = player::toggle),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (player.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Reproducir",
                    tint = Color.Black,
                    modifier = Modifier.size(40.dp),
                )
            }
            IconButton(onClick = player::next) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Siguiente", tint = Color.White, modifier = Modifier.size(40.dp))
            }
            IconButton(onClick = player::cycleRepeat) {
                Icon(
                    if (player.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = "Repetir",
                    tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) Green else Muted,
                )
            }
        }
    }
}

@Composable
private fun QueueSheet(player: PlayerController, onClose: () -> Unit) {
    val queue = player.queue
    val currentIndex = player.currentIndex
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .windowInsetsPadding(WindowInsets.systemBars)
            .padding(horizontal = 16.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Cerrar", color = Green, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable(onClick = onClose))
            Text("COLA", color = Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.2.sp)
            Spacer(Modifier.width(48.dp))
        }
        LazyColumn(Modifier.weight(1f)) {
            item {
                Text("Reproduciendo ahora", color = Muted, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 4.dp))
            }
            if (currentIndex in queue.indices) {
                item { QueueRow(queue[currentIndex], isCurrent = true) }
            }
            item {
                Text("A continuación", color = Muted, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 20.dp, bottom = 4.dp))
            }
            val upcoming = queue.withIndex().filter { it.index > currentIndex }
            if (upcoming.isEmpty()) {
                item { Text("No hay más canciones en la cola.", color = Muted, modifier = Modifier.padding(vertical = 8.dp)) }
            } else {
                items(upcoming, key = { it.index }) { indexed ->
                    val index = indexed.index
                    val track = indexed.value
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f).clickable { player.playQueueIndex(index) }) {
                            QueueRow(track, isCurrent = false)
                        }
                        IconButton(onClick = { player.moveQueueItem(index, index - 1) }, enabled = index > currentIndex + 1) {
                            Icon(Icons.Filled.ArrowUpward, contentDescription = "Subir", tint = if (index > currentIndex + 1) Color.White else Color(0xFF444444))
                        }
                        IconButton(onClick = { player.moveQueueItem(index, index + 1) }, enabled = index < queue.lastIndex) {
                            Icon(Icons.Filled.ArrowDownward, contentDescription = "Bajar", tint = if (index < queue.lastIndex) Color.White else Color(0xFF444444))
                        }
                        IconButton(onClick = { player.removeQueueItem(index) }) {
                            Icon(Icons.Filled.Close, contentDescription = "Quitar de la cola", tint = Muted)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QueueRow(track: QueueTrack, isCurrent: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        CoverArt(track.artUri, track.title.ifBlank { track.artist }, Modifier.size(44.dp), letterSize = 14.sp)
        Column(Modifier.padding(start = 10.dp)) {
            Text(
                track.title.ifBlank { "Sin título" },
                color = if (isCurrent) Green else Color.White,
                fontWeight = FontWeight.Medium,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun CreatePlaylistDialog(edits: LibraryEditsStore, onClose: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Nueva lista") },
        text = {
            TextField(
                value = name,
                onValueChange = { name = it },
                placeholder = { Text("Nombre de la lista") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val trimmed = name.trim()
                if (trimmed.isNotEmpty()) {
                    edits.createPlaylist(trimmed)
                    onClose()
                }
            }) { Text("Crear") }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text("Cancelar") }
        },
    )
}

@Composable
private fun AddToPlaylistDialog(edits: LibraryEditsStore, trackId: Long, onClose: () -> Unit) {
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Agregar a lista") },
        text = {
            Column {
                if (edits.playlists.isEmpty()) {
                    Text("Todavía no tienes listas.", color = Muted, modifier = Modifier.padding(bottom = 8.dp))
                }
                edits.playlists.forEach { playlist ->
                    val has = trackId in playlist.trackIds
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (has) edits.removeTrack(playlist.id, trackId) else edits.addTrack(playlist.id, trackId)
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(playlist.name, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Icon(
                            if (has) Icons.Filled.Check else Icons.Filled.Add,
                            contentDescription = null,
                            tint = if (has) Green else Muted,
                        )
                    }
                }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextField(
                        value = newName,
                        onValueChange = { newName = it },
                        placeholder = { Text("Nueva lista…") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = {
                        val trimmed = newName.trim()
                        if (trimmed.isNotEmpty()) {
                            val id = edits.createPlaylist(trimmed)
                            edits.addTrack(id, trackId)
                            newName = ""
                        }
                    }) { Text("Crear") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) { Text("Listo") }
        },
    )
}

@Composable
private fun ShortcutGrid(items: List<Shortcut>, play: (List<Track>, Int) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { item ->
                    Row(
                        Modifier.weight(1f).height(56.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A2A2A)).clickable { play(item.tracks, 0) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (item.seed == "likes") {
                            Box(Modifier.size(56.dp).background(Color(0xFF3A1D4A)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Favorite, contentDescription = null, tint = Color.White)
                            }
                        } else {
                            CoverArt(item.art, item.seed, Modifier.size(56.dp), corner = 0.dp, letterSize = 18.sp)
                        }
                        Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 8.dp))
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun TrackRow(tracks: List<Track>, play: (List<Track>, Int) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(tracks, key = { it.id }) { track ->
            Column(Modifier.width(132.dp).clickable { play(tracks, tracks.indexOf(track)) }) {
                CoverArt(track.albumArtUri, track.album.ifBlank { track.title }, Modifier.size(132.dp), corner = 6.dp, letterSize = 36.sp)
                Text(track.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 12.dp))
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Color.Black else Color.White,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Green else Color(0xFF2A2A2A))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

@Composable
private fun LetterBubble(seed: String) {
    Box(Modifier.size(52.dp).clip(CircleShape).background(coverColor(seed)), contentAlignment = Alignment.Center) {
        Text(seed.trim().ifEmpty { "?" }.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DetectorNote(library: LibraryState) {
    val voice = library.hiddenVoice
    val other = library.hiddenOther
    val detail = buildString {
        if (voice > 0) append("$voice audios (notas de voz y grabaciones)")
        if (other > 0) {
            if (isNotEmpty()) append(" y ")
            append("$other tonos o archivos que no son canciones")
        }
    }
    Text(
        "Detector: se ocultaron $detail.",
        color = Muted,
        fontSize = 13.sp,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF18241C)).padding(12.dp),
    )
}

@Composable
private fun PermissionNote() {
    Text(
        "Permite el acceso a tu música para armar la biblioteca. Los audios de WhatsApp y las notas de voz no se muestran.",
        color = Color.White,
        modifier = Modifier.padding(16.dp),
    )
}

@Composable
private fun LoadingNote() {
    Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(color = Green, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
        Text("Buscando canciones…", color = Muted, modifier = Modifier.padding(start = 12.dp))
    }
}

@Composable
private fun EmptyNote(library: LibraryState) {
    Text(
        if (library.hiddenVoice + library.hiddenOther > 0) {
            "No quedó ninguna canción. El detector ocultó audios, notas de voz y tonos."
        } else {
            "No hay canciones en el celular. Agrega MP3, M4A o FLAC a Música o Descargas."
        },
        color = Color.White,
        modifier = Modifier.padding(16.dp),
    )
}

private data class Shortcut(val title: String, val seed: String, val art: android.net.Uri?, val tracks: List<Track>)

private data class AlbumGroup(
    val key: String,
    val name: String,
    val artist: String,
    val art: android.net.Uri?,
    val tracks: List<Track>,
)

private fun albumGroups(tracks: List<Track>): List<AlbumGroup> =
    tracks.filter { it.album.isNotBlank() }
        .groupBy { it.album + "\u0000" + it.artist }
        .map { (key, list) -> AlbumGroup(key, list.first().album, list.first().artist, list.first().albumArtUri, list) }
        .sortedBy { it.name.lowercase() }

private fun greeting(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 5..11 -> "Buenos días"
        in 12..19 -> "Buenas tardes"
        else -> "Buenas noches"
    }
}

private fun formatMs(ms: Long): String {
    val total = ms.coerceAtLeast(0L) / 1000L
    return "%d:%02d".format(total / 60, total % 60)
}
