package com.rellslife.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.rellslife.music.ui.RellsApp
import com.rellslife.music.ui.RellsTheme

class MainActivity : ComponentActivity() {
    private var player: PlayerController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val controller = PlayerController(this)
        player = controller
        controller.connect()
        setContent {
            RellsTheme {
                RellsApp(controller)
            }
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
