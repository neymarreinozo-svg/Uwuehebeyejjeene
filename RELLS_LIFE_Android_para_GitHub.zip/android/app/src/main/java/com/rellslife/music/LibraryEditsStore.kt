package com.rellslife.music

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Playlist(val id: String, val name: String, val trackIds: List<Long>)

/**
 * Canciones quitadas de Rell's Life (no se borran del celular, solo se ocultan en la app)
 * y listas de reproducción propias. Mismo patrón de persistencia que [FavoritesStore].
 */
class LibraryEditsStore(context: Context) {
    private val prefs = context.getSharedPreferences("rell_library_edits", Context.MODE_PRIVATE)

    var removedIds by mutableStateOf(loadRemoved())
        private set
    var playlists by mutableStateOf(loadPlaylists())
        private set

    fun isRemoved(id: Long): Boolean = id in removedIds

    fun remove(id: Long) {
        if (id in removedIds) return
        val next = removedIds + id
        removedIds = next
        prefs.edit().putStringSet("removed", next.map { it.toString() }.toHashSet()).apply()
        if (playlists.any { id in it.trackIds }) {
            playlists = playlists.map { it.copy(trackIds = it.trackIds.filter { trackId -> trackId != id }) }
            savePlaylists(playlists)
        }
    }

    fun createPlaylist(name: String): String {
        val id = "pl-" + System.currentTimeMillis()
        playlists = playlists + Playlist(id, name, emptyList())
        savePlaylists(playlists)
        return id
    }

    fun deletePlaylist(id: String) {
        playlists = playlists.filter { it.id != id }
        savePlaylists(playlists)
    }

    fun addTrack(playlistId: String, trackId: Long) {
        playlists = playlists.map {
            if (it.id == playlistId && trackId !in it.trackIds) it.copy(trackIds = it.trackIds + trackId) else it
        }
        savePlaylists(playlists)
    }

    fun removeTrack(playlistId: String, trackId: Long) {
        playlists = playlists.map {
            if (it.id == playlistId) it.copy(trackIds = it.trackIds.filter { id -> id != trackId }) else it
        }
        savePlaylists(playlists)
    }

    private fun loadRemoved(): Set<Long> =
        prefs.getStringSet("removed", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

    private fun savePlaylists(list: List<Playlist>) {
        val array = JSONArray()
        list.forEach { playlist ->
            val obj = JSONObject()
            obj.put("id", playlist.id)
            obj.put("name", playlist.name)
            obj.put("trackIds", JSONArray(playlist.trackIds))
            array.put(obj)
        }
        prefs.edit().putString("playlists", array.toString()).apply()
    }

    private fun loadPlaylists(): List<Playlist> {
        val raw = prefs.getString("playlists", null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                val idsArray = obj.getJSONArray("trackIds")
                val ids = (0 until idsArray.length()).map { j -> idsArray.getLong(j) }
                Playlist(obj.getString("id"), obj.getString("name"), ids)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
