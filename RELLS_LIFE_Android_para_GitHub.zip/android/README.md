# RELL'S LIFE

Reproductor de música local para Android. Interfaz oscura con inicio, búsqueda, biblioteca, me gusta y reproductor. El detector deja fuera notas de voz, audios de WhatsApp/Telegram, grabaciones, tonos, alarmas y podcasts. Una canción enviada por WhatsApp se queda si trae artista o álbum y dura lo suficiente.

## Subir a GitHub y sacar el APK

1. Crea un repositorio vacío en GitHub.
2. Descomprime este proyecto (la carpeta, no subas el zip como único archivo).
3. En la carpeta del proyecto:

```bash
git init
git add .
git commit -m "RELL'S LIFE"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

4. Abre **Actions** en el repo. El workflow **Build RELL'S LIFE APK** corre solo al hacer push a `main`.
5. Al terminar, descarga el artefacto **RELLS-LIFE-apk** e instálalo en el celular.

También puedes lanzarlo a mano desde la pestaña Actions con **Run workflow**.

## Permisos

El teléfono pide acceso a la música (y notificaciones, para los controles). Sin el permiso de audio la biblioteca queda vacía.
