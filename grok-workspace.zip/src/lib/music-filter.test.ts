import assert from "node:assert/strict";
import { test } from "node:test";
import { classify, type AudioCandidate } from "./music-filter.ts";

function audio(partial: Partial<AudioCandidate> & Pick<AudioCandidate, "displayName" | "path">): AudioCandidate {
  return {
    artist: "<unknown>",
    album: "<unknown>",
    durationMs: 180_000,
    mimeType: "audio/mpeg",
    sizeBytes: 3_000_000,
    isMusic: true,
    isRingtone: false,
    isNotification: false,
    isAlarm: false,
    isPodcast: false,
    ...partial,
  };
}

test("tagged song is kept", () => {
  assert.equal(classify(audio({ displayName: "bohemian.mp3", path: "Music/Queen", artist: "Queen", album: "A Night", durationMs: 355_000, sizeBytes: 9_000_000 })), "song");
});

test("whatsapp voice note is hidden", () => {
  assert.equal(classify(audio({ displayName: "PTT-20241112-WA0001.opus", path: "WhatsApp/Media/WhatsApp Voice Notes", durationMs: 15_000, mimeType: "audio/ogg" })), "voice");
});

test("long voice note is hidden", () => {
  assert.equal(classify(audio({ displayName: "PTT-20241112-WA0048.opus", path: "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes", durationMs: 180_000, mimeType: "audio/opus" })), "voice");
});

test("ringtone is hidden", () => {
  assert.equal(classify(audio({ displayName: "hangouts.mp3", path: "Ringtones", durationMs: 25_000, isRingtone: true, isMusic: false })), "other");
});

test("untagged whatsapp export is hidden", () => {
  assert.equal(classify(audio({ displayName: "AUD-20240101-WA0003.mp3", path: "WhatsApp/Media/WhatsApp Audio", durationMs: 55_000 })), "voice");
});

test("tagged song shared on whatsapp is kept", () => {
  assert.equal(classify(audio({ displayName: "AUD-20240101-WA0003.mp3", path: "WhatsApp/Media/WhatsApp Audio", artist: "Shakira", album: "Laundry", durationMs: 240_000 })), "song");
});

test("voice recording is hidden", () => {
  assert.equal(classify(audio({ displayName: "Nueva grabación 5.m4a", path: "Recordings", durationMs: 64_000, mimeType: "audio/mp4" })), "voice");
});

test("flac without music flag is kept", () => {
  assert.equal(classify(audio({ displayName: "song.flac", path: "Download", artist: "Vera Quin", album: "Luz", durationMs: 200_000, mimeType: "audio/flac", isMusic: false, sizeBytes: 20_000_000 })), "song");
});

test("telegram voice is hidden", () => {
  assert.equal(classify(audio({ displayName: "audio_123.ogg", path: "Telegram/Telegram Audio", durationMs: 30_000, mimeType: "audio/ogg" })), "voice");
});

test("podcast is hidden", () => {
  assert.equal(classify(audio({ displayName: "episode.mp3", path: "Podcasts/Show", artist: "Show", durationMs: 1_800_000, isPodcast: true })), "other");
});
