import { classify, type AudioCandidate, type AudioKind } from "./music-filter.ts";

export type DemoTrack = AudioCandidate & {
  id: string;
  title: string;
  color: string;
  kind: AudioKind;
};

function item(
  id: string,
  title: string,
  color: string,
  candidate: AudioCandidate,
): DemoTrack {
  return { ...candidate, id, title, color, kind: classify(candidate) };
}

const base = {
  album: "<unknown>",
  mimeType: "audio/mpeg",
  sizeBytes: 4_000_000,
  isMusic: true,
  isRingtone: false,
  isNotification: false,
  isAlarm: false,
  isPodcast: false,
};

export const LIBRARY: DemoTrack[] = [
  item("s1", "Medianoche en el centro", "#1DB954", { ...base, displayName: "medianoche.mp3", path: "Music/Luna Rell", artist: "Luna Rell", album: "Centro", durationMs: 186_000 }),
  item("s2", "Calle 9", "#509BF5", { ...base, displayName: "calle9.mp3", path: "Music/Los Faroles", artist: "Los Faroles", album: "Faroles", durationMs: 204_000 }),
  item("s3", "Verde neón", "#E8115B", { ...base, displayName: "verde.m4a", path: "Music/Marina Sol", artist: "Marina Sol", album: "Neón", durationMs: 172_000, mimeType: "audio/mp4" }),
  item("s4", "Sin mapa", "#F59B23", { ...base, displayName: "sin-mapa.flac", path: "Download", artist: "Diego Alva", album: "Mapas", durationMs: 221_000, mimeType: "audio/flac", isMusic: false, sizeBytes: 24_000_000 }),
  item("s5", "Eco", "#8D67AB", { ...base, displayName: "eco.ogg", path: "Music/Nube Gris", artist: "Nube Gris", album: "Eco", durationMs: 198_000, mimeType: "audio/ogg" }),
  item("s6", "Después de las 3", "#2D46B9", { ...base, displayName: "despues.mp3", path: "Music/RELL", artist: "RELL", album: "Noche", durationMs: 156_000 }),
  item("s7", "Vidrio", "#E13300", { ...base, displayName: "vidrio.mp3", path: "Music/Ambar Norte", artist: "Ambar Norte", album: "Vidrio", durationMs: 143_000 }),
  item("s8", "Horizonte", "#148A08", { ...base, displayName: "horizonte.mp3", path: "Music/Club Paraiso", artist: "Club Paraíso", album: "Club", durationMs: 210_000 }),
  item("s9", "Baja la luz", "#1ED760", { ...base, displayName: "baja.mp3", path: "Download", artist: "Vera Quin", album: "Luz", durationMs: 188_000 }),
  item("s10", "Tecla verde", "#3D91F4", { ...base, displayName: "AUD-20261101-WA0099.mp3", path: "WhatsApp/Media/WhatsApp Audio", artist: "Nico Rell", album: "Tecla", durationMs: 200_000 }),
  item("v1", "PTT-20261112-WA0042.opus", "#333", { ...base, displayName: "PTT-20261112-WA0042.opus", path: "WhatsApp/Media/WhatsApp Voice Notes", artist: "", album: "", durationMs: 18_000, mimeType: "audio/ogg", sizeBytes: 80_000 }),
  item("v2", "PTT-20261112-WA0048.opus", "#333", { ...base, displayName: "PTT-20261112-WA0048.opus", path: "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes", artist: "", album: "", durationMs: 125_000, mimeType: "audio/opus", sizeBytes: 400_000 }),
  item("v3", "AUD-20261110-WA0011.mp3", "#333", { ...base, displayName: "AUD-20261110-WA0011.mp3", path: "WhatsApp/Media/WhatsApp Audio", artist: "<unknown>", album: "<unknown>", durationMs: 55_000 }),
  item("v4", "Nueva grabación 7.m4a", "#333", { ...base, displayName: "Nueva grabación 7.m4a", path: "Recordings/Sound Recorder", artist: "<unknown>", album: "", durationMs: 48_000, mimeType: "audio/mp4" }),
  item("o1", "ringtone.mp3", "#333", { ...base, displayName: "ringtone.mp3", path: "Ringtones", artist: "", durationMs: 8_000, isRingtone: true, isMusic: false, sizeBytes: 90_000 }),
  item("o2", "episode.mp3", "#333", { ...base, displayName: "episode.mp3", path: "Podcasts/Show", artist: "Show", album: "Daily", durationMs: 1_800_000, isPodcast: true }),
];

export const SONGS = LIBRARY.filter((track) => track.kind === "song");
export const HIDDEN = LIBRARY.filter((track) => track.kind !== "song");
