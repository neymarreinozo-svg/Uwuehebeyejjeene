import { createServerFn } from "@tanstack/react-start";
import { execFile } from "node:child_process";
import { mkdir, readdir, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";

const exec = promisify(execFile);

export type ConvertedTrack = {
  id: string;
  title: string;
  artist: string;
  src: string;
};

function youtubeId(url: string): string | null {
  try {
    const parsed = new URL(url);
    if (parsed.hostname === "youtu.be") return parsed.pathname.slice(1).split("/")[0] || null;
    if (parsed.searchParams.get("v")) return parsed.searchParams.get("v");
    const parts = parsed.pathname.split("/").filter(Boolean);
    const shorts = parts.indexOf("shorts");
    if (shorts >= 0 && parts[shorts + 1]) return parts[shorts + 1] ?? null;
  } catch {
    return null;
  }
  return null;
}

export const convertYoutubeAudio = createServerFn({ method: "POST" })
  .inputValidator((input: { url: string }) => {
    const url = input?.url?.trim() ?? "";
    if (!/^https?:\/\//i.test(url) || !youtubeId(url)) {
      throw new Error("Pega un enlace de YouTube (watch, youtu.be o shorts).");
    }
    return { url };
  })
  .handler(async ({ data }): Promise<ConvertedTrack> => {
    const id = youtubeId(data.url)!;
    const dir = join(tmpdir(), `rells-${id}-${Date.now()}`);
    await mkdir(dir, { recursive: true });
    try {
      const bin = process.env.YT_DLP_BIN || "yt-dlp";
      let stdout = "";
      try {
        const result = await exec(
          bin,
          [
            "-f",
            "bestaudio/best",
            "--no-playlist",
            "-x",
            "--audio-format",
            "mp3",
            "--audio-quality",
            "0",
            "--print",
            "%(title)s\t%(uploader)s",
            "-o",
            join(dir, "%(id)s.%(ext)s"),
            data.url,
          ],
          { timeout: 120_000, maxBuffer: 2_000_000 },
        );
        stdout = result.stdout;
      } catch (error) {
        const message = error instanceof Error ? error.message : "yt-dlp falló";
        if (message.includes("ENOENT")) {
          throw new Error("En esta vista previa no está yt-dlp. El APK de Android sí descarga el audio en el teléfono.");
        }
        throw new Error("No se pudo convertir ese enlace. Prueba otro video público.");
      }
      const [titleRaw, artistRaw] = stdout.trim().split("\n").pop()?.split("\t") ?? [];
      const files = await readdir(dir);
      const audio = files.find((name) => /\.(mp3|m4a|webm|opus|ogg)$/i.test(name));
      if (!audio) throw new Error("La conversión no dejó un archivo de audio.");
      const bytes = await readFile(join(dir, audio));
      if (bytes.byteLength > 18_000_000) {
        throw new Error("El audio pesa demasiado para reproducirlo en la vista previa.");
      }
      const mime = audio.endsWith(".mp3") ? "audio/mpeg" : audio.endsWith(".m4a") ? "audio/mp4" : "audio/webm";
      return {
        id: `yt-${id}`,
        title: (titleRaw || "YouTube").slice(0, 120),
        artist: (artistRaw || "YouTube").slice(0, 80),
        src: `data:${mime};base64,${bytes.toString("base64")}`,
      };
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  });
