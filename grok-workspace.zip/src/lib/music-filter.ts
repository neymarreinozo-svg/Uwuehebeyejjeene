export type AudioKind = "song" | "voice" | "other";

export type AudioCandidate = {
  displayName: string;
  path: string;
  artist: string;
  album: string;
  durationMs: number;
  mimeType: string;
  sizeBytes: number;
  isMusic: boolean;
  isRingtone: boolean;
  isNotification: boolean;
  isAlarm: boolean;
  isPodcast: boolean;
};

const audExport = /^aud-\d{6,8}-wa\d+/;
const voiceArtists = new Set([
  "voice memos",
  "notas de voz",
  "sound recorder",
  "grabadora de voz",
  "voice recorder",
  "grabadora",
]);
const voiceFolders = [
  "voice notes",
  "voicenotes",
  "voice note",
  "voice messages",
  "notas de voz",
  "nota de voz",
  "voice memos",
  "ptt",
  "statuses",
];
const recordingFolders = [
  "sound recorder",
  "soundrecorder",
  "voice recorder",
  "voicerecorder",
  "grabaciones",
  "call recordings",
  "callrecord",
  "sound_recorder",
  "recordings",
];
const recorderNames = [
  "nueva grabacion",
  "new recording",
  "audio recording",
  "voice memo",
  "nota de voz",
  "memo de voz",
  "grabacion de voz",
];
const musicExts = new Set(["mp3", "m4a", "flac", "wav", "aac", "wma", "alac", "aiff", "aif", "mp4"]);

export function normalize(value: string): string {
  return value.normalize("NFD").replace(/\p{M}+/gu, "").toLowerCase().trim();
}

function unknown(folded: string): boolean {
  return (
    folded.length === 0 ||
    folded === "unknown" ||
    folded === "<unknown>" ||
    folded === "<unknown artist>" ||
    folded === "artista desconocido"
  );
}

function extOf(name: string): string {
  return name.includes(".") ? name.slice(name.lastIndexOf(".") + 1) : "";
}

function folders(path: string): string[] {
  return normalize(path)
    .split(/[/\\]+/)
    .filter((part) => part.length > 0);
}

function folderHas(path: string, needles: string[]): boolean {
  return folders(path).some((folder) => needles.some((needle) => folder.includes(needle)));
}

function isMessenger(path: string): boolean {
  const folded = normalize(path);
  if (
    folded.includes("whatsapp") ||
    folded.includes("telegram") ||
    folded.includes("org.thoughtcrime.securesms") ||
    folded.includes("com.instagram.android") ||
    folded.includes("facebook/messenger")
  ) {
    return true;
  }
  return folders(path).some((folder) => folder === "signal" || folder === "messenger");
}

export function classify(candidate: AudioCandidate): AudioKind {
  const name = normalize(candidate.displayName);
  const artistFold = normalize(candidate.artist);
  const albumFold = normalize(candidate.album);
  const ext = extOf(name);
  const mime = normalize(candidate.mimeType);
  const unknownArtist = unknown(artistFold);
  const unknownAlbum = unknown(albumFold) || albumFold === "music";
  const hasIdentity = !unknownArtist || !unknownAlbum;
  if (voiceArtists.has(artistFold)) return "voice";
  if (candidate.isRingtone || folderHas(candidate.path, ["ringtone"])) return "other";
  if (candidate.isNotification || folderHas(candidate.path, ["notification"])) return "other";
  if (candidate.isAlarm || folderHas(candidate.path, ["alarm"])) return "other";
  if (candidate.isPodcast || folderHas(candidate.path, ["podcast"])) return "other";

  const voiceExt =
    ext === "opus" ||
    ext === "amr" ||
    ext === "3gp" ||
    ext === "3gpp" ||
    mime.includes("opus") ||
    mime.includes("amr") ||
    mime.includes("3gpp");
  const ogg = ext === "ogg" || mime.includes("ogg");
  const musicExt = musicExts.has(ext);
  const messenger = isMessenger(candidate.path);
  const voiceFolder = folderHas(candidate.path, voiceFolders);
  const recordingFolder = folderHas(candidate.path, recordingFolders);
  const pttName = name.startsWith("ptt-") || name.startsWith("ptt_") || name.startsWith("ptt ");
  const audName = audExport.test(name);
  const recorderName =
    recorderNames.some((label) => name.includes(label)) ||
    name.startsWith("recording") ||
    name.startsWith("grabacion");

  if (candidate.durationMs >= 1 && candidate.durationMs < 20_000) {
    return voiceExt || messenger || pttName || voiceFolder || recorderName ? "voice" : "other";
  }
  if (pttName || voiceFolder) return "voice";
  if (recorderName && !hasIdentity) return "voice";
  if (recordingFolder && (voiceExt || ogg || !hasIdentity || (ext === "m4a" && unknownArtist))) return "voice";
  if (messenger && (voiceExt || ogg || pttName)) return "voice";
  if (messenger && audName && (voiceExt || ogg || !hasIdentity || (candidate.durationMs >= 1 && candidate.durationMs < 75_000))) {
    return "voice";
  }
  if (messenger && !hasIdentity && !musicExt) return "voice";
  if (voiceExt && !hasIdentity) return "voice";
  if (ogg && !hasIdentity && candidate.durationMs < 90_000) return "voice";
  if (!candidate.isMusic && !musicExt && !(ogg && hasIdentity && candidate.durationMs >= 90_000)) return "other";
  if (candidate.sizeBytes >= 1 && candidate.sizeBytes < 40_000 && ext !== "wav" && ext !== "flac") return "other";
  return "song";
}
