import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { SONGS, type DemoTrack } from "@/lib/demo-library";
import { normalize } from "@/lib/music-filter";
import { convertYoutubeAudio } from "@/lib/youtube-convert.server";

type Tab = "home" | "search" | "library" | "convert";
type RepeatMode = "off" | "all" | "one";
type Playable = DemoTrack & { src?: string };

const FAV_KEY = "rells-favs";

function formatMs(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}

function greeting(): string {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 12) return "Buenos días";
  if (hour >= 12 && hour < 20) return "Buenas tardes";
  return "Buenas noches";
}

function Cover({ track, className }: { track: Pick<DemoTrack, "title" | "color">; className?: string }) {
  return (
    <div
      className={`grid shrink-0 place-items-center font-bold text-white ${className ?? ""}`}
      style={{ background: `linear-gradient(145deg, ${track.color}, #121212 140%)` }}
    >
      {track.title.trim().slice(0, 1).toUpperCase()}
    </div>
  );
}

export function RellsApp() {
  const [tab, setTab] = useState<Tab>("home");
  const [query, setQuery] = useState("");
  const [hello] = useState(greeting);
  const [favs, setFavs] = useState<string[]>([]);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [queue, setQueue] = useState<string[]>(SONGS.map((song) => song.id));
  const [playing, setPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<RepeatMode>("off");
  const [nowOpen, setNowOpen] = useState(false);
  const [lib, setLib] = useState<"songs" | "artists" | "liked">("songs");
  const [imported, setImported] = useState<Playable[]>([]);
  const [convertUrl, setConvertUrl] = useState("");
  const [convertMsg, setConvertMsg] = useState("Pega un enlace de YouTube. En el teléfono el APK lo guarda en Música. Aquí se convierte si el servidor tiene yt-dlp.");
  const [converting, setConverting] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const songs = useMemo<Playable[]>(() => [...imported, ...SONGS], [imported]);
  const model = useRef({ queue, repeat, shuffle, currentId });
  model.current = { queue, repeat, shuffle, currentId };

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(FAV_KEY) || "[]") as string[];
      if (Array.isArray(saved)) setFavs(saved);
    } catch {
      /* ignore broken storage */
    }
  }, []);

  const current = songs.find((song) => song.id === currentId) ?? null;
  const fileSrc = current?.src;

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (!fileSrc) {
      audio.pause();
      return;
    }
    if (audio.src !== fileSrc) audio.src = fileSrc;
    if (playing) void audio.play().catch(() => setPlaying(false));
    else audio.pause();
  }, [fileSrc, playing]);

  useEffect(() => {
    if (!playing || !current || fileSrc) return;
    const id = window.setInterval(() => {
      setPosition((pos) => {
        const next = pos + 500;
        if (next >= current.durationMs) return current.durationMs;
        return next;
      });
    }, 500);
    return () => window.clearInterval(id);
  }, [playing, current, fileSrc]);

  useEffect(() => {
    if (current && position >= current.durationMs && playing) {
      if (repeat === "one") {
        setPosition(0);
        return;
      }
      const list = model.current.queue;
      const index = list.indexOf(current.id);
      if (shuffle) {
        const options = list.filter((id) => id !== current.id);
        const pick = options[Math.floor(Math.random() * options.length)] ?? current.id;
        setCurrentId(pick);
        setPosition(0);
        return;
      }
      if (index >= 0 && index < list.length - 1) {
        setCurrentId(list[index + 1] ?? null);
        setPosition(0);
        return;
      }
      if (repeat === "all" && list.length > 0) {
        setCurrentId(list[0] ?? null);
        setPosition(0);
        return;
      }
      setPlaying(false);
    }
  }, [position, current, playing, repeat, shuffle]);

  function toggleFav(id: string) {
    setFavs((prev) => {
      const next = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      localStorage.setItem(FAV_KEY, JSON.stringify(next));
      return next;
    });
  }

  function playTrack(id: string, nextQueue: string[]) {
    setQueue(nextQueue);
    setCurrentId(id);
    setPosition(0);
    setPlaying(true);
  }

  function toggle() {
    if (!current) {
      const first = songs[0];
      if (first) playTrack(first.id, songs.map((song) => song.id));
      return;
    }
    if (!playing && position >= current.durationMs) setPosition(0);
    setPlaying((value) => !value);
  }

  function skip(direction: 1 | -1) {
    if (!current) return;
    if (direction < 0 && position > 3000) {
      setPosition(0);
      return;
    }
    const list = queue.length ? queue : songs.map((song) => song.id);
    const index = list.indexOf(current.id);
    const nextIndex = (index + direction + list.length) % list.length;
    const next = list[nextIndex];
    if (next) {
      setCurrentId(next);
      setPosition(0);
      setPlaying(true);
    }
  }

  const results = useMemo(() => {
    const needle = normalize(query);
    if (!needle) return songs;
    return songs.filter((song) =>
      [song.title, song.artist, song.album].some((value) => normalize(value).includes(needle)),
    );
  }, [query]);

  const liked = songs.filter((song) => favs.includes(song.id));
  const albums = useMemo(() => {
    const map = new Map<string, DemoTrack[]>();
    for (const song of songs) {
      const key = song.album || song.title;
      map.set(key, [...(map.get(key) ?? []), song]);
    }
    return [...map.entries()];
  }, []);

  return (
    <div className="flex min-h-dvh justify-center bg-black">
    <div className="relative flex h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-[#121212] text-white">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-64 bg-gradient-to-b from-[#1b4332] to-transparent" />
      <main className="relative z-10 min-h-0 flex-1 overflow-y-auto pb-4">
        {tab === "home" && (
          <div>
            <div className="flex items-center gap-2.5 px-4 pt-5">
              <img src="/rells-mark.png" alt="" className="h-8 w-8 rounded-md" />
              <p className="text-[13px] font-bold tracking-[0.16em] text-[#1DB954]">RELL'S LIFE</p>
            </div>
            <h1 className="px-4 pb-4 pt-2 text-[28px] font-bold">{hello}</h1>
            <div className="grid grid-cols-2 gap-2 px-4">
              {[
                { title: "Tus me gusta", songs: liked.length ? liked : songs.slice(0, 4), color: "#3a1d4a" },
                { title: albums[0]?.[0] ?? "Centro", songs: albums[0]?.[1] ?? songs, color: songs[0]?.color ?? "#1DB954" },
                { title: albums[1]?.[0] ?? "Faroles", songs: albums[1]?.[1] ?? songs, color: songs[1]?.color ?? "#509BF5" },
                { title: albums[2]?.[0] ?? "Neón", songs: albums[2]?.[1] ?? songs, color: songs[2]?.color ?? "#E8115B" },
              ].map((card) => (
                <button
                  key={card.title}
                  type="button"
                  onClick={() => {
                    const first = card.songs[0];
                    if (first) playTrack(first.id, card.songs.map((song) => song.id));
                  }}
                  className="flex h-14 items-center overflow-hidden rounded bg-[#2a2a2a] text-left"
                >
                  <span className="h-14 w-14 shrink-0" style={{ background: card.color }} />
                  <span className="px-2 text-[13px] font-bold leading-tight">{card.title}</span>
                </button>
              ))}
            </div>
            <h2 className="px-4 pb-3 pt-6 text-[20px] font-bold">Hecho para ti</h2>
            <div className="no-scrollbar flex gap-3 overflow-x-auto px-4">
              {songs.slice(0, 8).map((song) => (
                <button key={song.id} type="button" onClick={() => playTrack(song.id, songs.map((item) => item.id))} className="w-[132px] shrink-0 text-left">
                  <Cover track={song} className="h-[132px] w-[132px] rounded-md text-[36px]" />
                  <p className="truncate pt-2 text-[13px]">{song.title}</p>
                  <p className="truncate text-[12px] text-[#b3b3b3]">{song.artist}</p>
                </button>
              ))}
            </div>
            <h2 className="px-4 pb-2 pt-6 text-[20px] font-bold">Canciones</h2>
            {songs.map((song) => (
              <SongRow key={song.id} song={song} active={song.id === currentId} fav={favs.includes(song.id)} onPlay={() => playTrack(song.id, songs.map((item) => item.id))} onFav={() => toggleFav(song.id)} />
            ))}
          </div>
        )}
        {tab === "search" && (
          <div className="pt-4">
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="¿Qué quieres escuchar?"
              className="mx-4 mb-3 w-[calc(100%-2rem)] rounded-full bg-[#242424] px-4 py-3 text-[15px] outline-none"
            />
            {results.length === 0 ? (
              <p className="px-6 text-[#b3b3b3]">Nada coincide con “{query}”.</p>
            ) : (
              results.map((song) => (
                <SongRow key={song.id} song={song} active={song.id === currentId} fav={favs.includes(song.id)} onPlay={() => playTrack(song.id, results.map((item) => item.id))} onFav={() => toggleFav(song.id)} />
              ))
            )}
          </div>
        )}
        {tab === "library" && (
          <div className="pt-4">
            <h1 className="px-4 text-[26px] font-bold">Biblioteca</h1>
            <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 py-3">
              {(
                [
                  ["songs", "Canciones"],
                  ["artists", "Artistas"],
                  ["liked", "Me gusta"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setLib(id)}
                  className={`rounded-full px-3.5 py-2 text-[13px] font-semibold ${lib === id ? "bg-[#1DB954] text-black" : "bg-[#2a2a2a]"}`}
                >
                  {label}
                </button>
              ))}
            </div>
            {lib === "artists" ? (
              [...new Set(songs.map((song) => song.artist))].map((artist) => (
                <button
                  key={artist}
                  type="button"
                  onClick={() => {
                    const list = songs.filter((song) => song.artist === artist);
                    const first = list[0];
                    if (first) playTrack(first.id, list.map((song) => song.id));
                  }}
                  className="flex w-full items-center gap-3 px-4 py-2 text-left"
                >
                  <span className="grid h-12 w-12 place-items-center rounded-full font-bold" style={{ background: "#1DB954" }}>
                    {artist.slice(0, 1)}
                  </span>
                  <span>
                    <span className="block font-semibold">{artist}</span>
                    <span className="text-[13px] text-[#b3b3b3]">{songs.filter((song) => song.artist === artist).length} canciones</span>
                  </span>
                </button>
              ))
            ) : (
              (lib === "liked" ? liked : songs).map((song) => (
                <SongRow
                  key={song.id}
                  song={song}
                  active={song.id === currentId}
                  fav={favs.includes(song.id)}
                  onPlay={() => playTrack(song.id, (lib === "liked" ? liked : songs).map((item) => item.id))}
                  onFav={() => toggleFav(song.id)}
                />
              ))
            )}
            {lib === "liked" && liked.length === 0 && <p className="px-4 text-[#b3b3b3]">Todavía no marcas me gusta.</p>}
          </div>
        )}
        {tab === "convert" && (
          <div className="px-4 pt-5">
            <h1 className="text-[26px] font-bold">Convertir</h1>
            <p className="pb-4 pt-2 text-[14px] text-[#b3b3b3]">{convertMsg}</p>
            <input
              value={convertUrl}
              onChange={(event) => setConvertUrl(event.target.value)}
              placeholder="https://youtu.be/..."
              className="w-full rounded-full bg-[#242424] px-4 py-3 text-[15px] outline-none"
            />
            <button
              type="button"
              disabled={converting || !convertUrl.trim()}
              onClick={() => {
                setConverting(true);
                setConvertMsg("Convirtiendo audio…");
                void convertYoutubeAudio({ data: { url: convertUrl.trim() } })
                  .then((track) => {
                    const song: Playable = {
                      id: track.id,
                      title: track.title,
                      color: "#1DB954",
                      kind: "song",
                      src: track.src,
                      displayName: `${track.title}.mp3`,
                      path: "Music/RELLS LIFE",
                      artist: track.artist,
                      album: "YouTube",
                      durationMs: 180_000,
                      mimeType: "audio/mpeg",
                      sizeBytes: 3_000_000,
                      isMusic: true,
                      isRingtone: false,
                      isNotification: false,
                      isAlarm: false,
                      isPodcast: false,
                    };
                    setImported((prev) => [song, ...prev.filter((item) => item.id !== song.id)]);
                    playTrack(song.id, [song.id, ...songs.map((item) => item.id)]);
                    setConvertUrl("");
                    setConvertMsg(`Listo: ${track.title}. Ya está en la cola.`);
                  })
                  .catch((error: unknown) => {
                    setConvertMsg(error instanceof Error ? error.message : "No se pudo convertir.");
                  })
                  .finally(() => setConverting(false));
              }}
              className="mt-3 rounded-full bg-[#1DB954] px-5 py-3 text-[14px] font-bold text-black disabled:opacity-40"
            >
              {converting ? "Espera…" : "Descargar audio"}
            </button>
          </div>
        )}
      </main>
      {current && (
        <button type="button" onClick={() => setNowOpen(true)} className="relative z-20 flex h-16 w-full items-center gap-2 bg-[#181818] px-2 text-left">
          <Cover track={current} className="h-12 w-12 rounded text-[16px]" />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[14px] font-medium">{current.title}</span>
            <span className="block truncate text-[12px] text-[#b3b3b3]">{current.artist}</span>
          </span>
          <span
            role="button"
            tabIndex={0}
            onClick={(event) => {
              event.stopPropagation();
              toggleFav(current.id);
            }}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                event.stopPropagation();
                toggleFav(current.id);
              }
            }}
            className="grid h-11 w-11 place-items-center"
            aria-label="Favorito"
          >
            <Heart on={favs.includes(current.id)} />
          </span>
          <span
            role="button"
            tabIndex={0}
            onClick={(event) => {
              event.stopPropagation();
              toggle();
            }}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                event.stopPropagation();
                toggle();
              }
            }}
            className="grid h-11 w-11 place-items-center"
            aria-label={playing ? "Pausar" : "Reproducir"}
          >
            {playing ? <Pause /> : <Play />}
          </span>
        </button>
      )}
      <audio
        ref={audioRef}
        onTimeUpdate={(event) => setPosition(event.currentTarget.currentTime * 1000)}
        onLoadedMetadata={(event) => {
          const ms = Math.round(event.currentTarget.duration * 1000);
          if (!Number.isFinite(ms) || !current) return;
          setImported((prev) => prev.map((song) => (song.id === current.id ? { ...song, durationMs: ms } : song)));
        }}
        onEnded={() => setPosition(current?.durationMs ?? 0)}
      />
      <nav className="relative z-20 grid grid-cols-4 bg-black pb-2 pt-2 text-[11px]">
        <NavButton label="Inicio" active={tab === "home"} onClick={() => setTab("home")} icon={<HomeIcon />} />
        <NavButton label="Buscar" active={tab === "search"} onClick={() => setTab("search")} icon={<SearchIcon />} />
        <NavButton label="Biblioteca" active={tab === "library"} onClick={() => setTab("library")} icon={<LibIcon />} />
        <NavButton label="Bajar" active={tab === "convert"} onClick={() => setTab("convert")} icon={<DownIcon />} />
      </nav>
      {nowOpen && current && (
        <div className="absolute inset-0 z-30 flex flex-col bg-gradient-to-b from-[#1b4332] to-[#121212] px-5 pb-6 pt-4">
          <div className="flex items-center">
            <button type="button" aria-label="Cerrar" onClick={() => setNowOpen(false)} className="grid h-11 w-11 place-items-center">
              <Chevron />
            </button>
            <div className="flex-1 text-center">
              <p className="text-[10px] tracking-[0.14em] text-[#b3b3b3]">REPRODUCIENDO</p>
              <p className="text-[13px] font-bold">Tu biblioteca</p>
            </div>
            <span className="w-11" />
          </div>
          <Cover track={current} className="mt-6 aspect-square w-full rounded-lg text-[72px]" />
          <div className="mt-6 flex items-center gap-3">
            <div className="min-w-0 flex-1">
              <p className="truncate text-[22px] font-bold">{current.title}</p>
              <p className="truncate text-[15px] text-[#b3b3b3]">{current.artist}</p>
            </div>
            <button type="button" aria-label="Favorito" onClick={() => toggleFav(current.id)} className="grid h-11 w-11 place-items-center">
              <Heart on={favs.includes(current.id)} />
            </button>
          </div>
          <input
            aria-label="Posición"
            type="range"
            min={0}
            max={current.durationMs}
            value={Math.min(position, current.durationMs)}
            onChange={(event) => setPosition(Number(event.target.value))}
            className="mt-4 w-full accent-[#1DB954]"
          />
          <div className="flex justify-between text-[12px] text-[#b3b3b3]">
            <span>{formatMs(position)}</span>
            <span>{formatMs(current.durationMs)}</span>
          </div>
          <div className="mt-4 flex items-center justify-between px-2">
            <button type="button" aria-label="Aleatorio" onClick={() => setShuffle((value) => !value)} className={shuffle ? "text-[#1DB954]" : "text-[#b3b3b3]"}>
              <ShuffleIcon />
            </button>
            <button type="button" aria-label="Anterior" onClick={() => skip(-1)}>
              <Skip dir="prev" />
            </button>
            <button type="button" aria-label={playing ? "Pausar" : "Reproducir"} onClick={toggle} className="grid h-16 w-16 place-items-center rounded-full bg-[#1DB954] text-black">
              {playing ? <Pause /> : <Play />}
            </button>
            <button type="button" aria-label="Siguiente" onClick={() => skip(1)}>
              <Skip dir="next" />
            </button>
            <button
              type="button"
              aria-label="Repetir"
              onClick={() => setRepeat((value) => (value === "off" ? "all" : value === "all" ? "one" : "off"))}
              className={repeat === "off" ? "text-[#b3b3b3]" : "text-[#1DB954]"}
            >
              {repeat === "one" ? "1" : "↺"}
            </button>
          </div>
        </div>
      )}
    </div>
    </div>
  );
}

function SongRow({
  song,
  active,
  fav,
  onPlay,
  onFav,
}: {
  song: DemoTrack;
  active: boolean;
  fav: boolean;
  onPlay: () => void;
  onFav: () => void;
}) {
  return (
    <div className="flex items-center gap-3 px-3 py-1.5">
      <button type="button" onClick={onPlay} className="flex min-w-0 flex-1 items-center gap-3 text-left">
        <Cover track={song} className="h-12 w-12 rounded text-[16px]" />
        <span className="min-w-0">
          <span className={`block truncate text-[15px] font-medium ${active ? "text-[#1DB954]" : ""}`}>{song.title}</span>
          <span className="block truncate text-[13px] text-[#b3b3b3]">{song.artist}</span>
        </span>
      </button>
      <span className="text-[12px] text-[#b3b3b3]">{formatMs(song.durationMs)}</span>
      <button type="button" aria-label="Favorito" onClick={onFav} className="grid h-11 w-11 place-items-center">
        <Heart on={fav} />
      </button>
    </div>
  );
}

function NavButton({ label, active, onClick, icon }: { label: string; active: boolean; onClick: () => void; icon: ReactNode }) {
  return (
    <button type="button" onClick={onClick} className={`grid justify-items-center gap-1 ${active ? "text-white" : "text-[#b3b3b3]"}`}>
      {icon}
      {label}
    </button>
  );
}

function Heart({ on }: { on: boolean }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill={on ? "#1DB954" : "none"} stroke={on ? "#1DB954" : "#b3b3b3"} strokeWidth="2">
      <path d="M12 20s-7-4.4-7-9a4 4 0 0 1 7-2 4 4 0 0 1 7 2c0 4.6-7 9-7 9z" />
    </svg>
  );
}
function Play() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
      <path d="M8 5v14l11-7z" />
    </svg>
  );
}
function Pause() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
      <path d="M6 5h4v14H6zM14 5h4v14h-4z" />
    </svg>
  );
}
function HomeIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 4 3 11h2v8h5v-5h4v5h5v-8h2z" />
    </svg>
  );
}
function SearchIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.5-3.5" />
    </svg>
  );
}
function DownIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 4v11" />
      <path d="m7 11 5 5 5-5" />
      <path d="M5 20h14" />
    </svg>
  );
}
function LibIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
      <path d="M4 5h2v14H4zM8 5h12v2H8zM8 11h12v2H8zM8 17h12v2H8z" />
    </svg>
  );
}
function Chevron() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
      <path d="m6 9 6 6 6-6" />
    </svg>
  );
}
function Skip({ dir }: { dir: "prev" | "next" }) {
  const flip = dir === "prev" ? "scaleX(-1)" : undefined;
  return (
    <svg width="34" height="34" viewBox="0 0 24 24" fill="white" style={{ transform: flip }}>
      <path d="M6 5v14h2V5zm3 7 9 6V6z" />
    </svg>
  );
}
function ShuffleIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="m16 3 4 4-4 4" />
      <path d="M4 7h11l5 0" />
      <path d="m16 17 4 4-4 0" />
      <path d="M4 17h2l9 7" />
    </svg>
  );
}
