import { createFileRoute } from "@tanstack/react-router";
import { RellsApp } from "@/components/rells-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <RellsApp />;
}
