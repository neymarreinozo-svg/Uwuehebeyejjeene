package com.rellslife.music

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class FavoritesStore(context: Context) {
    private val prefs = context.getSharedPreferences("rell_favorites", Context.MODE_PRIVATE)
    var ids by mutableStateOf(loadIds())
        private set
    var recents by mutableStateOf(loadRecents())
        private set

    fun isFavorite(id: Long): Boolean = id in ids

    fun toggle(id: Long) {
        val next = ids.toMutableSet()
        if (!next.add(id)) next.remove(id)
        ids = next
        prefs.edit().putStringSet("ids", next.map { it.toString() }.toHashSet()).apply()
    }

    fun pushRecent(id: Long) {
        val next = (listOf(id) + recents.filter { it != id }).take(20)
        recents = next
        prefs.edit().putString("recents", next.joinToString(",")).apply()
    }

    private fun loadIds(): Set<Long> =
        prefs.getStringSet("ids", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

    private fun loadRecents(): List<Long> =
        prefs.getString("recents", "").orEmpty().split(',').mapNotNull { it.toLongOrNull() }
}
