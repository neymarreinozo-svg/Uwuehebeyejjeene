package com.rellslife.music

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.io.File
import java.util.concurrent.TimeUnit

object YoutubeAudio {
    data class Saved(val title: String, val artist: String)

    fun download(context: Context, pageUrl: String): Saved {
        ensurePipe()
        val info = StreamInfo.getInfo(ServiceList.YouTube, pageUrl.trim())
        val audio = info.audioStreams.maxByOrNull { it.averageBitrate }
            ?: throw IllegalStateException("Ese video no tiene pista de audio.")
        val ext = audio.format?.suffix ?: "m4a"
        val mime = audio.format?.mimeType ?: "audio/mp4"
        val title = info.name.ifBlank { "YouTube" }.take(80)
        val artist = info.uploaderName?.ifBlank { "YouTube" } ?: "YouTube"
        val fileName = buildString {
            append(title.replace(Regex("""[\\/:*?"<>|]"""), " ").trim().take(60).ifBlank { "audio" })
            append(".")
            append(ext)
        }
        val bytes = http.newCall(
            okhttp3.Request.Builder().url(audio.url).header("User-Agent", USER_AGENT).build(),
        ).execute().use { response ->
            if (!response.isSuccessful) error("No se pudo bajar el audio (${response.code})")
            response.body.bytes()
        }
        save(context, fileName, mime, title, artist, bytes)
        return Saved(title, artist)
    }

    private fun save(context: Context, name: String, mime: String, title: String, artist: String, bytes: ByteArray) {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, name)
                put(MediaStore.Audio.Media.MIME_TYPE, mime)
                put(MediaStore.Audio.Media.TITLE, title)
                put(MediaStore.Audio.Media.ARTIST, artist)
                put(MediaStore.Audio.Media.IS_MUSIC, 1)
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/RELLS LIFE")
            }
            val uri = context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("No se pudo crear el archivo de música")
            context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: error("No se pudo escribir el audio")
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            val folder = File(dir, "RELLS LIFE").apply { mkdirs() }
            File(folder, name).writeBytes(bytes)
        }
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    @Synchronized
    private fun ensurePipe() {
        if (ready) return
        NewPipe.init(PipeDownloader(http))
        ready = true
    }

    private var ready = false

    private class PipeDownloader(private val client: OkHttpClient) : Downloader() {
        override fun execute(request: Request): Response {
            val body = request.dataToSend()?.toRequestBody()
            val builder = okhttp3.Request.Builder().url(request.url()).method(request.httpMethod(), body)
            builder.header("User-Agent", USER_AGENT)
            for ((name, values) in request.headers()) {
                for (value in values) builder.addHeader(name, value)
            }
            client.newCall(builder.build()).execute().use { response ->
                if (response.code == 429) throw ReCaptchaException("YouTube pidió verificación", request.url())
                val headers = response.headers.toMultimap()
                return Response(
                    response.code,
                    response.message,
                    headers,
                    response.body?.string(),
                    response.request.url.toString(),
                )
            }
        }
    }

    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
}
