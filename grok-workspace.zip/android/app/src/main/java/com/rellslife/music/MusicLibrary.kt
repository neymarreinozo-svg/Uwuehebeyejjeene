package com.rellslife.music

import android.content.ContentResolver
import android.content.ContentUris
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

object MusicLibrary {
    data class Scan(val songs: List<Track>, val hiddenVoice: Int, val hiddenOther: Int)

    fun scan(resolver: ContentResolver): Scan {
        query(resolver, projection(includeData = true))?.let { return it }
        return query(resolver, projection(includeData = false)) ?: Scan(emptyList(), 0, 0)
    }

    private fun query(resolver: ContentResolver, projection: Array<String>): Scan? {
        val songs = mutableListOf<Track>()
        var voice = 0
        var other = 0
        try {
            resolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                "${MediaStore.Audio.Media.TITLE} ASC",
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    when (val kind = classify(cursor)) {
                        AudioKind.VOICE -> voice++
                        AudioKind.OTHER -> other++
                        AudioKind.SONG -> songs.add(toTrack(cursor))
                    }
                }
            }
        } catch (_: SecurityException) {
            return Scan(emptyList(), 0, 0)
        } catch (_: IllegalArgumentException) {
            return null
        }
        val collator = java.text.Collator.getInstance(java.util.Locale("es")).apply {
            strength = java.text.Collator.PRIMARY
        }
        songs.sortWith { a, b -> collator.compare(a.title, b.title) }
        return Scan(songs, voice, other)
    }

    private fun classify(cursor: Cursor): AudioKind {
        val display = cursor.string(MediaStore.Audio.Media.DISPLAY_NAME)
            .ifBlank { cursor.string(MediaStore.Audio.Media.TITLE) }
        val rel = cursor.string(MediaStore.Audio.Media.RELATIVE_PATH)
        val data = cursor.string(MediaStore.Audio.Media.DATA)
        return MusicFilter.kind(
            AudioCandidate(
                displayName = display,
                path = listOf(rel, data).filter { it.isNotBlank() }.joinToString("/"),
                artist = cursor.string(MediaStore.Audio.Media.ARTIST),
                album = cursor.string(MediaStore.Audio.Media.ALBUM),
                durationMs = cursor.long(MediaStore.Audio.Media.DURATION),
                mimeType = cursor.string(MediaStore.Audio.Media.MIME_TYPE),
                sizeBytes = cursor.long(MediaStore.Audio.Media.SIZE),
                isMusic = cursor.flag(MediaStore.Audio.Media.IS_MUSIC),
                isRingtone = cursor.flag(MediaStore.Audio.Media.IS_RINGTONE),
                isNotification = cursor.flag(MediaStore.Audio.Media.IS_NOTIFICATION),
                isAlarm = cursor.flag(MediaStore.Audio.Media.IS_ALARM),
                isPodcast = cursor.flag(MediaStore.Audio.Media.IS_PODCAST),
            ),
        )
    }

    private fun toTrack(cursor: Cursor): Track {
        val id = cursor.long(MediaStore.Audio.Media._ID)
        val display = cursor.string(MediaStore.Audio.Media.DISPLAY_NAME)
        val rawTitle = cursor.string(MediaStore.Audio.Media.TITLE)
        val title = rawTitle.ifBlank {
            display.substringBeforeLast('.').ifBlank { "Sin título" }
        }
        val albumId = cursor.long(MediaStore.Audio.Media.ALBUM_ID)
        val art = if (albumId > 0) {
            ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
        } else {
            null
        }
        return Track(
            id = id,
            title = title,
            artist = prettyArtist(cursor.string(MediaStore.Audio.Media.ARTIST)),
            album = prettyAlbum(cursor.string(MediaStore.Audio.Media.ALBUM)),
            durationMs = cursor.long(MediaStore.Audio.Media.DURATION),
            dateAdded = cursor.long(MediaStore.Audio.Media.DATE_ADDED),
            uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
            albumArtUri = art,
        )
    }

    private fun prettyArtist(raw: String): String {
        val value = raw.trim()
        if (
            value.isBlank() ||
            value.equals("<unknown>", true) ||
            value.equals("<unknown artist>", true) ||
            value.equals("unknown", true)
        ) {
            return "Artista desconocido"
        }
        return value
    }

    private fun prettyAlbum(raw: String): String {
        val value = raw.trim()
        if (value.isBlank() || value.equals("<unknown>", true) || value.equals("unknown", true) || value.equals("music", true)) {
            return ""
        }
        return value
    }

    private fun projection(includeData: Boolean): Array<String> {
        val cols = mutableListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.IS_MUSIC,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_ALARM,
            MediaStore.Audio.Media.IS_PODCAST,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATE_ADDED,
        )
        if (includeData) cols += MediaStore.Audio.Media.DATA
        if (Build.VERSION.SDK_INT >= 29) cols += MediaStore.Audio.Media.RELATIVE_PATH
        return cols.toTypedArray()
    }

    private fun Cursor.string(col: String): String {
        val index = getColumnIndex(col)
        if (index < 0 || isNull(index)) return ""
        return getString(index) ?: ""
    }

    private fun Cursor.long(col: String): Long {
        val index = getColumnIndex(col)
        if (index < 0 || isNull(index)) return 0L
        return getLong(index)
    }

    private fun Cursor.flag(col: String): Boolean {
        val index = getColumnIndex(col)
        if (index < 0 || isNull(index)) return false
        return getInt(index) != 0
    }
}
