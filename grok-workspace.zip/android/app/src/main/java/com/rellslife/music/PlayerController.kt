package com.rellslife.music

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.media.audiofx.AudioEffect
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

class PlayerController(private val activity: ComponentActivity) {
    var connected by mutableStateOf(false)
    var isPlaying by mutableStateOf(false)
    var title by mutableStateOf("")
    var artist by mutableStateOf("")
    var album by mutableStateOf("")
    var artUri by mutableStateOf<Uri?>(null)
    var mediaId by mutableStateOf<String?>(null)
    var position by mutableLongStateOf(0L)
    var duration by mutableLongStateOf(0L)
    var shuffle by mutableStateOf(false)
    var repeatMode by mutableStateOf(Player.REPEAT_MODE_OFF)
    var hasTrack by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var sleepMinutes by mutableIntStateOf(0)

    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private var pending: Pair<List<Track>, Int>? = null
    private var uiVisible = true
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val current = controller
            if (current == null || !uiVisible || !current.isPlaying) return
            position = current.currentPosition.coerceAtLeast(0L)
            duration = current.duration.coerceAtLeast(0L)
            handler.postDelayed(this, 1000)
        }
    }
    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(player)
        }

        override fun onPlayerError(error: PlaybackException) {
            this@PlayerController.error = "No se pudo reproducir esta canción"
        }
    }

    fun connect() {
        if (future != null) return
        val token = SessionToken(activity, ComponentName(activity, PlayerService::class.java))
        val next = MediaController.Builder(activity, token).buildAsync()
        future = next
        next.addListener(
            {
                try {
                    attach(next.get())
                } catch (_: Exception) {
                    error = "No se pudo abrir el reproductor"
                }
            },
            ContextCompat.getMainExecutor(activity),
        )
        refreshSleep()
    }

    fun setUiVisible(visible: Boolean) {
        uiVisible = visible
        scheduleTick()
    }

    fun refreshSleep() {
        sleepMinutes = PlayerService.sleepMinutesLeft(activity)
    }

    fun cycleSleep() {
        val next = when (sleepMinutes) {
            0 -> 15
            in 1..15 -> 30
            in 16..30 -> 45
            in 31..45 -> 60
            else -> 0
        }
        PlayerService.scheduleSleep(activity, next)
        sleepMinutes = next
    }

    fun openEqualizer() {
        val session = PlayerService.audioSessionId()
        val intent = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL).apply {
            putExtra(AudioEffect.EXTRA_PACKAGE_NAME, activity.packageName)
            putExtra(AudioEffect.EXTRA_AUDIO_SESSION, session)
            putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
        }
        try {
            activity.startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            error = "Este celular no trae ecualizador"
        }
    }

    fun release() {
        handler.removeCallbacksAndMessages(null)
        val current = controller
        controller = null
        if (current != null) {
            current.removeListener(listener)
            current.release()
        } else {
            future?.let { MediaController.releaseFuture(it) }
        }
        future = null
    }

    fun playAll(tracks: List<Track>, index: Int) {
        if (tracks.isEmpty()) return
        val safe = index.coerceIn(0, tracks.lastIndex)
        val current = controller
        if (current == null) {
            pending = tracks to safe
            return
        }
        send(current, tracks, safe)
    }

    fun toggle() {
        val current = controller ?: return
        if (current.isPlaying) current.pause() else current.play()
    }

    fun next() {
        controller?.seekToNext()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        val target = ms.coerceAtLeast(0L)
        controller?.seekTo(target)
        position = target
    }

    fun toggleShuffle() {
        val current = controller ?: return
        current.shuffleModeEnabled = !current.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val current = controller ?: return
        current.repeatMode = when (current.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    private fun attach(mediaController: MediaController) {
        controller = mediaController
        mediaController.addListener(listener)
        sync(mediaController)
        connected = true
        pending?.let { (tracks, index) ->
            pending = null
            send(mediaController, tracks, index)
        }
    }

    private fun send(mediaController: MediaController, tracks: List<Track>, index: Int) {
        mediaController.setMediaItems(tracks.map { it.toMediaItem() }, index, 0L)
        mediaController.prepare()
        mediaController.play()
        error = null
    }

    private fun sync(player: Player) {
        isPlaying = player.isPlaying
        shuffle = player.shuffleModeEnabled
        repeatMode = player.repeatMode
        hasTrack = player.mediaItemCount > 0 && player.currentMediaItem != null
        val metadata = player.mediaMetadata
        title = metadata.title?.toString().orEmpty()
        artist = metadata.artist?.toString().orEmpty()
        album = metadata.albumTitle?.toString().orEmpty()
        artUri = metadata.artworkUri
        mediaId = player.currentMediaItem?.mediaId
        duration = player.duration.coerceAtLeast(0L)
        position = player.currentPosition.coerceAtLeast(0L)
        if (player.isPlaying) error = null
        scheduleTick()
    }

    private fun scheduleTick() {
        handler.removeCallbacks(tick)
        val current = controller
        if (uiVisible && current != null && current.isPlaying) {
            position = current.currentPosition.coerceAtLeast(0L)
            duration = current.duration.coerceAtLeast(0L)
            handler.postDelayed(tick, 1000)
        }
    }
}
