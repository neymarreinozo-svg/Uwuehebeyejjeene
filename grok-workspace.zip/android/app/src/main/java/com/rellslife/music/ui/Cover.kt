package com.rellslife.music.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage

private val palette = listOf(
    Color(0xFF1DB954),
    Color(0xFF509BF5),
    Color(0xFFE8115B),
    Color(0xFFF59B23),
    Color(0xFF8D67AB),
    Color(0xFF2D46B9),
    Color(0xFFE13300),
    Color(0xFF148A08),
)

fun coverColor(seed: String): Color {
    val index = (seed.hashCode() and Int.MAX_VALUE) % palette.size
    return palette[index]
}

@Composable
fun CoverArt(
    uri: Uri?,
    seed: String,
    modifier: Modifier,
    corner: Dp = 4.dp,
    letterSize: TextUnit = 18.sp,
) {
    val letter = seed.trim().ifEmpty { "?" }.take(1).uppercase()
    val shape = RoundedCornerShape(corner)
    if (uri == null) {
        LetterCover(letter, seed, modifier.clip(shape), letterSize)
        return
    }
    SubcomposeAsyncImage(
        model = uri,
        contentDescription = null,
        modifier = modifier.clip(shape),
        contentScale = ContentScale.Crop,
        loading = { LetterCover(letter, seed, Modifier.fillMaxSize(), letterSize) },
        error = { LetterCover(letter, seed, Modifier.fillMaxSize(), letterSize) },
    )
}

@Composable
private fun LetterCover(letter: String, seed: String, modifier: Modifier, letterSize: TextUnit) {
    val first = coverColor(seed)
    val second = coverColor(seed + "#")
    Box(
        modifier.background(Brush.linearGradient(listOf(first, second))),
        contentAlignment = Alignment.Center,
    ) {
        Text(letter, color = Color.White, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = letterSize))
    }
}
