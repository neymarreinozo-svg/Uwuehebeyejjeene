package com.rellslife.music

enum class AudioKind { SONG, VOICE, OTHER }

data class AudioCandidate(
    val displayName: String,
    val path: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val mimeType: String,
    val sizeBytes: Long,
    val isMusic: Boolean,
    val isRingtone: Boolean,
    val isNotification: Boolean,
    val isAlarm: Boolean,
    val isPodcast: Boolean,
)

object MusicFilter {
    private val audExport = Regex("""^aud-\d{6,8}-wa\d+""")
    private val voiceArtists = setOf(
        "voice memos",
        "notas de voz",
        "sound recorder",
        "grabadora de voz",
        "voice recorder",
        "grabadora",
    )
    private val voiceFolders = listOf(
        "voice notes",
        "voicenotes",
        "voice note",
        "voice messages",
        "notas de voz",
        "nota de voz",
        "voice memos",
        "ptt",
        "statuses",
    )
    private val recordingFolders = listOf(
        "sound recorder",
        "soundrecorder",
        "voice recorder",
        "voicerecorder",
        "grabaciones",
        "call recordings",
        "callrecord",
        "sound_recorder",
        "recordings",
    )
    private val recorderNames = listOf(
        "nueva grabacion",
        "new recording",
        "audio recording",
        "voice memo",
        "nota de voz",
        "memo de voz",
        "grabacion de voz",
    )
    private val musicExts = setOf("mp3", "m4a", "flac", "wav", "aac", "wma", "alac", "aiff", "aif", "mp4")

    fun kind(c: AudioCandidate): AudioKind {
        val name = fold(c.displayName)
        val artistFold = fold(c.artist)
        val albumFold = fold(c.album)
        val ext = extOf(name)
        val mime = fold(c.mimeType)
        val unknownArtist = unknown(artistFold)
        val unknownAlbum = unknown(albumFold) || albumFold == "music"
        val hasIdentity = !unknownArtist || !unknownAlbum

        if (artistFold in voiceArtists) return AudioKind.VOICE
        if (c.isRingtone || folderHas(c.path, listOf("ringtone"))) return AudioKind.OTHER
        if (c.isNotification || folderHas(c.path, listOf("notification"))) return AudioKind.OTHER
        if (c.isAlarm || folderHas(c.path, listOf("alarm"))) return AudioKind.OTHER
        if (c.isPodcast || folderHas(c.path, listOf("podcast"))) return AudioKind.OTHER

        val voiceExt = ext in setOf("opus", "amr", "3gp", "3gpp") ||
            mime.contains("opus") || mime.contains("amr") || mime.contains("3gpp")
        val ogg = ext == "ogg" || mime.contains("ogg")
        val musicExt = ext in musicExts
        val messenger = isMessenger(c.path)
        val voiceFolder = folderHas(c.path, voiceFolders)
        val recordingFolder = folderHas(c.path, recordingFolders)
        val pttName = name.startsWith("ptt-") || name.startsWith("ptt_") || name.startsWith("ptt ")
        val audName = audExport.containsMatchIn(name)
        val recorderName = recorderNames.any { name.contains(it) } ||
            name.startsWith("recording") || name.startsWith("grabacion")

        if (c.durationMs in 1 until 20_000) {
            return if (voiceExt || messenger || pttName || voiceFolder || recorderName) AudioKind.VOICE else AudioKind.OTHER
        }
        if (pttName || voiceFolder) return AudioKind.VOICE
        if (recorderName && !hasIdentity) return AudioKind.VOICE
        if (recordingFolder && (voiceExt || ogg || !hasIdentity || (ext == "m4a" && unknownArtist))) {
            return AudioKind.VOICE
        }
        if (messenger && (voiceExt || ogg || pttName)) return AudioKind.VOICE
        if (messenger && audName && (voiceExt || ogg || !hasIdentity || c.durationMs in 1 until 75_000)) {
            return AudioKind.VOICE
        }
        if (messenger && !hasIdentity && !musicExt) return AudioKind.VOICE
        if (voiceExt && !hasIdentity) return AudioKind.VOICE
        if (ogg && !hasIdentity && c.durationMs < 90_000) return AudioKind.VOICE
        if (!c.isMusic && !musicExt && !(ogg && hasIdentity && c.durationMs >= 90_000)) return AudioKind.OTHER
        if (c.sizeBytes in 1 until 40_000 && ext != "wav" && ext != "flac") return AudioKind.OTHER
        return AudioKind.SONG
    }

    fun normalize(s: String): String = fold(s)

    private fun unknown(folded: String): Boolean =
        folded.isBlank() || folded in setOf("unknown", "<unknown>", "<unknown artist>", "artista desconocido")

    private fun extOf(name: String): String = if ('.' in name) name.substringAfterLast('.') else ""

    private fun folders(path: String): List<String> =
        fold(path).split(Regex("""[/\\]+""")).filter { it.isNotBlank() }

    private fun folderHas(path: String, needles: List<String>): Boolean =
        folders(path).any { folder -> needles.any { folder.contains(it) } }

    private fun isMessenger(path: String): Boolean {
        val p = fold(path)
        if (
            p.contains("whatsapp") ||
            p.contains("telegram") ||
            p.contains("org.thoughtcrime.securesms") ||
            p.contains("com.instagram.android") ||
            p.contains("facebook/messenger")
        ) {
            return true
        }
        return folders(path).any { it == "signal" || it == "messenger" }
    }

    private fun fold(s: String): String =
        java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase()
            .trim()
}
