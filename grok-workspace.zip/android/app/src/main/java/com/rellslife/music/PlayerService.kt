package com.rellslife.music

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlayerService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private val sleepStop = Runnable {
        mediaSession?.player?.pause()
        prefs().edit().remove(KEY_SLEEP_UNTIL).apply()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true,
            )
            setHandleAudioBecomingNoisy(true)
            setWakeMode(C.WAKE_MODE_LOCAL)
        }
        val sessionIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionIntent)
            .build()
        val pending = prefs().getInt(KEY_SLEEP_REQUEST, -1)
        if (pending >= 0) {
            prefs().edit().remove(KEY_SLEEP_REQUEST).apply()
            armSleep(pending)
        } else {
            restoreSleep()
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady) {
            player?.pause()
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (instance === this) instance = null
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    private fun armSleep(minutes: Int) {
        handler.removeCallbacks(sleepStop)
        if (minutes <= 0) {
            prefs().edit().remove(KEY_SLEEP_UNTIL).apply()
            return
        }
        val until = SystemClock.elapsedRealtime() + minutes * 60_000L
        prefs().edit().putLong(KEY_SLEEP_UNTIL, until).apply()
        handler.postDelayed(sleepStop, minutes * 60_000L)
    }

    private fun restoreSleep() {
        val until = prefs().getLong(KEY_SLEEP_UNTIL, 0L)
        val left = until - SystemClock.elapsedRealtime()
        if (left > 1_000L) handler.postDelayed(sleepStop, left) else prefs().edit().remove(KEY_SLEEP_UNTIL).apply()
    }

    private fun prefs() = getSharedPreferences(PREFS, MODE_PRIVATE)

    companion object {
        private const val PREFS = "rell_player"
        private const val KEY_SLEEP_UNTIL = "sleep_until"
        private const val KEY_SLEEP_REQUEST = "sleep_request"
        private var instance: PlayerService? = null

        fun audioSessionId(): Int {
            val player = instance?.mediaSession?.player as? ExoPlayer ?: return 0
            return player.audioSessionId
        }

        fun scheduleSleep(context: Context, minutes: Int) {
            val running = instance
            if (running != null) {
                running.armSleep(minutes)
            } else if (minutes > 0) {
                context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_SLEEP_REQUEST, minutes).apply()
            } else {
                context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_SLEEP_UNTIL).remove(KEY_SLEEP_REQUEST).apply()
            }
        }

        fun sleepMinutesLeft(context: Context): Int {
            val until = context.getSharedPreferences(PREFS, MODE_PRIVATE).getLong(KEY_SLEEP_UNTIL, 0L)
            val left = until - SystemClock.elapsedRealtime()
            if (left <= 0L) return 0
            return ((left + 59_999L) / 60_000L).toInt()
        }
    }
}
