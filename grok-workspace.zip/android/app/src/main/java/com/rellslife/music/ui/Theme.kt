package com.rellslife.music.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF121212)
val Surface = Color(0xFF181818)
val Green = Color(0xFF1DB954)
val Muted = Color(0xFFB3B3B3)

private val scheme = darkColorScheme(
    primary = Green,
    onPrimary = Color.Black,
    background = Bg,
    surface = Surface,
    onBackground = Color.White,
    onSurface = Color.White,
)

@Composable
fun RellsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
