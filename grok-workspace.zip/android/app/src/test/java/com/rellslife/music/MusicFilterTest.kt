package com.rellslife.music

import org.junit.Assert.assertEquals
import org.junit.Test

class MusicFilterTest {
    @Test fun taggedSongIsKept() {
        assertEquals(AudioKind.SONG, MusicFilter.kind(audio(
            displayName = "bohemian.mp3",
            path = "Music/Queen",
            artist = "Queen",
            album = "A Night",
            durationMs = 355_000,
            sizeBytes = 9_000_000,
        )))
    }

    @Test fun whatsAppVoiceNoteIsHidden() {
        assertEquals(AudioKind.VOICE, MusicFilter.kind(audio(
            displayName = "PTT-20241112-WA0001.opus",
            path = "WhatsApp/Media/WhatsApp Voice Notes",
            durationMs = 15_000,
            mimeType = "audio/ogg",
            isMusic = true,
        )))
    }

    @Test fun longVoiceNoteIsHidden() {
        assertEquals(AudioKind.VOICE, MusicFilter.kind(audio(
            displayName = "PTT-20241112-WA0048.opus",
            path = "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes",
            durationMs = 180_000,
            mimeType = "audio/opus",
        )))
    }

    @Test fun ringtoneFlagIsHidden() {
        assertEquals(AudioKind.OTHER, MusicFilter.kind(audio(
            displayName = "hangouts.mp3",
            path = "Ringtones",
            durationMs = 25_000,
            isRingtone = true,
            isMusic = false,
        )))
    }

    @Test fun notificationIsHidden() {
        assertEquals(AudioKind.OTHER, MusicFilter.kind(audio(
            displayName = "notify.mp3",
            path = "Notifications",
            durationMs = 2_000,
            isNotification = true,
            isMusic = false,
        )))
    }

    @Test fun alarmIsHidden() {
        assertEquals(AudioKind.OTHER, MusicFilter.kind(audio(
            displayName = "alarm.mp3",
            path = "Alarms",
            isAlarm = true,
            isMusic = false,
        )))
    }

    @Test fun podcastIsHidden() {
        assertEquals(AudioKind.OTHER, MusicFilter.kind(audio(
            displayName = "episode.mp3",
            path = "Podcasts/Show",
            artist = "Show",
            durationMs = 1_800_000,
            isPodcast = true,
        )))
    }

    @Test fun veryShortClipIsHidden() {
        assertEquals(AudioKind.OTHER, MusicFilter.kind(audio(
            displayName = "blip.mp3",
            path = "Music",
            artist = "Queen",
            durationMs = 8_000,
        )))
    }

    @Test fun untaggedWhatsAppExportIsHidden() {
        assertEquals(AudioKind.VOICE, MusicFilter.kind(audio(
            displayName = "AUD-20240101-WA0003.mp3",
            path = "WhatsApp/Media/WhatsApp Audio",
            artist = "<unknown>",
            album = "<unknown>",
            durationMs = 55_000,
        )))
    }

    @Test fun taggedSongSharedOnWhatsAppIsKept() {
        assertEquals(AudioKind.SONG, MusicFilter.kind(audio(
            displayName = "AUD-20240101-WA0003.mp3",
            path = "WhatsApp/Media/WhatsApp Audio",
            artist = "Shakira",
            album = "Laundry",
            durationMs = 240_000,
        )))
    }

    @Test fun voiceRecordingIsHidden() {
        assertEquals(AudioKind.VOICE, MusicFilter.kind(audio(
            displayName = "Nueva grabación 5.m4a",
            path = "Recordings",
            artist = "<unknown>",
            durationMs = 64_000,
            mimeType = "audio/mp4",
        )))
    }

    @Test fun flacWithoutMusicFlagIsKept() {
        assertEquals(AudioKind.SONG, MusicFilter.kind(audio(
            displayName = "song.flac",
            path = "Download",
            artist = "Vera Quin",
            album = "Luz",
            durationMs = 200_000,
            mimeType = "audio/flac",
            isMusic = false,
            sizeBytes = 20_000_000,
        )))
    }

    @Test fun looseOpusIsHidden() {
        assertEquals(AudioKind.VOICE, MusicFilter.kind(audio(
            displayName = "voice.opus",
            path = "Download",
            durationMs = 40_000,
            mimeType = "audio/opus",
            artist = "",
        )))
    }

    @Test fun taggedOggAlbumIsKept() {
        assertEquals(AudioKind.SONG, MusicFilter.kind(audio(
            displayName = "album.ogg",
            path = "Music/Nube Gris",
            artist = "Nube Gris",
            album = "Eco",
            durationMs = 240_000,
            mimeType = "audio/ogg",
        )))
    }

    @Test fun telegramVoiceIsHidden() {
        assertEquals(AudioKind.VOICE, MusicFilter.kind(audio(
            displayName = "audio_123.ogg",
            path = "Telegram/Telegram Audio",
            durationMs = 30_000,
            mimeType = "audio/ogg",
        )))
    }

    @Test fun tinyFileIsHidden() {
        assertEquals(AudioKind.OTHER, MusicFilter.kind(audio(
            displayName = "blip.mp3",
            path = "Music",
            artist = "Queen",
            durationMs = 25_000,
            sizeBytes = 10_000,
        )))
    }

    @Test fun twentySecondSongIsKept() {
        assertEquals(AudioKind.SONG, MusicFilter.kind(audio(
            displayName = "intro.mp3",
            path = "Music",
            artist = "Queen",
            album = "Hits",
            durationMs = 20_000,
        )))
    }

    @Test fun voiceMemoArtistIsHidden() {
        assertEquals(AudioKind.VOICE, MusicFilter.kind(audio(
            displayName = "memo.m4a",
            path = "Voice Memos",
            artist = "Voice Memos",
            durationMs = 90_000,
            mimeType = "audio/mp4",
        )))
    }

    private fun audio(
        displayName: String,
        path: String,
        artist: String = "<unknown>",
        album: String = "<unknown>",
        durationMs: Long = 180_000,
        mimeType: String = "audio/mpeg",
        sizeBytes: Long = 3_000_000,
        isMusic: Boolean = true,
        isRingtone: Boolean = false,
        isNotification: Boolean = false,
        isAlarm: Boolean = false,
        isPodcast: Boolean = false,
    ) = AudioCandidate(
        displayName, path, artist, album, durationMs, mimeType, sizeBytes,
        isMusic, isRingtone, isNotification, isAlarm, isPodcast,
    )
}
