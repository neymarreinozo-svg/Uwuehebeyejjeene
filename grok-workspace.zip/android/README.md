# RELL'S LIFE

Reproductor de música local para Android. Interfaz oscura con inicio, búsqueda, biblioteca, me gusta y reproductor. La pestaña **Bajar** convierte un enlace de YouTube a audio y lo guarda en `Música/RELLS LIFE` para que aparezca en la biblioteca. El detector deja fuera notas de voz, audios de WhatsApp/Telegram, grabaciones, tonos, alarmas y podcasts.

## Subir a GitHub y sacar el APK

El workflow [`.github/workflows/android.yml`](.github/workflows/android.yml) llama a [`scripts/build-apk.sh`](scripts/build-apk.sh). Ese script acepta las licencias del SDK, instala la plataforma Android 35 y compila el APK.

1. Crea un repositorio vacío en GitHub.
2. Sube esta carpeta (no el zip como único archivo).
3. En la carpeta del proyecto:

```bash
git init
git add .
git commit -m "RELL'S LIFE"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

4. En **Actions**, espera **Build RELL'S LIFE APK**.
5. Descarga el artefacto **RELLS-LIFE-apk**.

También puedes lanzarlo a mano con **Run workflow**.


## Permisos

El teléfono pide acceso a la música (y notificaciones, para los controles). Sin el permiso de audio la biblioteca queda vacía.
