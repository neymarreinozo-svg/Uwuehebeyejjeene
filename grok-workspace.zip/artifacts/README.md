# yt-download.sh — Descargar videos con yt-dlp + FFmpeg

Script sencillo y práctico para descargar videos (y audio) de YouTube y muchos otros sitios usando **yt-dlp** + **FFmpeg**.

## Requisitos

- **yt-dlp** (recomendado instalar la versión oficial)
- **FFmpeg** (para unir pistas de video+audio y convertir formatos)

### Instalar yt-dlp (Linux / macOS)

```bash
# Opción recomendada (binario standalone)
sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp
sudo chmod a+rx /usr/local/bin/yt-dlp

# O con pip
pip install -U yt-dlp
```

### Instalar FFmpeg

```bash
# Ubuntu / Debian
sudo apt update && sudo apt install ffmpeg

# macOS (Homebrew)
brew install ffmpeg

# Windows: descarga desde https://ffmpeg.org/download.html
```

## Uso

```bash
# Dar permisos de ejecución
chmod +x yt-download.sh

# Ayuda
./yt-download.sh --help

# Descargar mejor calidad (video + audio)
./yt-download.sh "https://www.youtube.com/watch?v=XXXXXXXX"

# Máximo 1080p
./yt-download.sh -f 1080p "https://youtu.be/XXXXXXXX"

# Solo audio en MP3
./yt-download.sh -a "https://www.youtube.com/watch?v=XXXXXXXX"
# o
./yt-download.sh -f mp3 "https://..."

# Cambiar carpeta de salida
./yt-download.sh -o ~/Videos "https://..."

# Ver todos los formatos disponibles sin descargar
./yt-download.sh -l "https://..."
```

## Opciones principales

| Opción | Descripción |
|--------|-------------|
| `-f best` | Mejor calidad disponible (por defecto) |
| `-f 1080p` / `720p` / `480p` | Limitar resolución máxima |
| `-f mp3` o `-a` | Solo audio en MP3 de alta calidad |
| `-f m4a` | Solo audio en M4A |
| `-o DIR` | Carpeta donde guardar los archivos |
| `-l` | Listar formatos disponibles |
| `-h` | Mostrar ayuda |

## Notas

- yt-dlp usa FFmpeg automáticamente para unir el mejor video + mejor audio cuando están en streams separados (lo más común en YouTube).
- Los archivos se guardan por defecto en la carpeta `./downloads`.
- Funciona con YouTube, Vimeo, Twitter/X, TikTok, Instagram y cientos de sitios más.
