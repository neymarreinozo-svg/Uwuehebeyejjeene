#!/bin/bash
# ============================================================
#  yt-download.sh  —  Descargar y convertir videos con yt-dlp + FFmpeg
# ============================================================
# Requisitos: yt-dlp y ffmpeg instalados
# Uso:  ./yt-download.sh [opciones] <URL>
# ============================================================

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuración por defecto
OUTPUT_DIR="./downloads"
FORMAT="best"
AUDIO_ONLY=false
QUALITY=""
FILENAME_TEMPLATE="%(title)s [%(id)s].%(ext)s"
YT_DLP_BIN="yt-dlp"

# Detectar si yt-dlp está disponible
if ! command -v yt-dlp &> /dev/null; then
    if [ -x "/tmp/yt-dlp" ]; then
        YT_DLP_BIN="/tmp/yt-dlp"
    else
        echo -e "${RED}Error: yt-dlp no está instalado.${NC}"
        echo "Instálalo con:"
        echo "  curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp"
        echo "  chmod a+rx /usr/local/bin/yt-dlp"
        exit 1
    fi
fi

# Verificar FFmpeg
if ! command -v ffmpeg &> /dev/null; then
    echo -e "${RED}Error: FFmpeg no está instalado.${NC}"
    echo "Es necesario para unir video+audio y convertir formatos."
    exit 1
fi

show_help() {
    cat << EOF
${GREEN}yt-download.sh${NC} — Descargar videos de YouTube (y otros sitios) con yt-dlp + FFmpeg

${YELLOW}Uso:${NC}
  $0 [opciones] <URL>

${YELLOW}Opciones:${NC}
  -o, --output DIR       Carpeta de salida (default: ./downloads)
  -f, --format FORMAT    Formato de descarga:
                           best      → Mejor calidad disponible (video+audio)
                           1080p     → Máximo 1080p
                           720p      → Máximo 720p
                           480p      → Máximo 480p
                           mp3       → Solo audio en MP3
                           m4a       → Solo audio en M4A
                           bestvideo → Solo video (sin audio)
  -a, --audio            Descargar solo audio (equivale a -f mp3)
  -n, --name TEMPLATE    Plantilla de nombre de archivo
  -l, --list             Listar formatos disponibles (sin descargar)
  -h, --help             Mostrar esta ayuda

${YELLOW}Ejemplos:${NC}
  $0 "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  $0 -f 1080p "https://youtu.be/xxxxx"
  $0 -a "https://www.youtube.com/watch?v=xxxxx"          # Solo audio MP3
  $0 -f mp3 -o ~/Musica "https://..."
  $0 -l "https://..."                                    # Ver formatos disponibles

EOF
}

# Parsear argumentos
LIST_FORMATS=false
URL=""

while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -o|--output)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        -f|--format)
            FORMAT="$2"
            shift 2
            ;;
        -a|--audio)
            AUDIO_ONLY=true
            FORMAT="mp3"
            shift
            ;;
        -n|--name)
            FILENAME_TEMPLATE="$2"
            shift 2
            ;;
        -l|--list)
            LIST_FORMATS=true
            shift
            ;;
        -*)
            echo -e "${RED}Opción desconocida: $1${NC}"
            show_help
            exit 1
            ;;
        *)
            URL="$1"
            shift
            ;;
    esac
done

if [ -z "$URL" ]; then
    echo -e "${RED}Error: Debes proporcionar una URL.${NC}"
    show_help
    exit 1
fi

# Crear carpeta de salida
mkdir -p "$OUTPUT_DIR"

echo -e "${BLUE}▶ URL:${NC} $URL"
echo -e "${BLUE}▶ Carpeta:${NC} $OUTPUT_DIR"

# Solo listar formatos
if [ "$LIST_FORMATS" = true ]; then
    echo -e "${YELLOW}Listando formatos disponibles...${NC}"
    $YT_DLP_BIN -F "$URL"
    exit 0
fi

# Construir el selector de formato según la opción
case "$FORMAT" in
    best)
        FORMAT_SELECTOR="bestvideo+bestaudio/best"
        EXTRA_ARGS=()
        ;;
    1080p)
        FORMAT_SELECTOR="bestvideo[height<=1080]+bestaudio/best[height<=1080]"
        EXTRA_ARGS=()
        ;;
    720p)
        FORMAT_SELECTOR="bestvideo[height<=720]+bestaudio/best[height<=720]"
        EXTRA_ARGS=()
        ;;
    480p)
        FORMAT_SELECTOR="bestvideo[height<=480]+bestaudio/best[height<=480]"
        EXTRA_ARGS=()
        ;;
    mp3)
        FORMAT_SELECTOR="bestaudio/best"
        EXTRA_ARGS=(-x --audio-format mp3 --audio-quality 0)
        ;;
    m4a)
        FORMAT_SELECTOR="bestaudio/best"
        EXTRA_ARGS=(-x --audio-format m4a --audio-quality 0)
        ;;
    bestvideo)
        FORMAT_SELECTOR="bestvideo"
        EXTRA_ARGS=()
        ;;
    *)
        # Formato personalizado (el usuario puede pasar un selector de yt-dlp)
        FORMAT_SELECTOR="$FORMAT"
        EXTRA_ARGS=()
        ;;
esac

echo -e "${BLUE}▶ Formato:${NC} $FORMAT ($FORMAT_SELECTOR)"
echo -e "${GREEN}Descargando...${NC}"
echo

# Ejecutar yt-dlp
$YT_DLP_BIN \
    -f "$FORMAT_SELECTOR" \
    --merge-output-format mp4 \
    -o "$OUTPUT_DIR/$FILENAME_TEMPLATE" \
    --no-mtime \
    --progress \
    "${EXTRA_ARGS[@]}" \
    "$URL"

echo
echo -e "${GREEN}✓ ¡Descarga completada!${NC}"
echo -e "Archivos guardados en: ${YELLOW}$OUTPUT_DIR${NC}"
